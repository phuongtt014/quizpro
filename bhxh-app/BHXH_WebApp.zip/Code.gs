/**
 * =====================================================================
 *  WEB APP QUẢN LÝ & TÍNH BHXH HÀNG THÁNG
 *  Nền tảng: Google Apps Script – Database: chính Google Sheet chứa script
 *  Cài đặt: xem file HUONG_DAN.md
 * =====================================================================
 */

// ---------------------------------------------------------------------
// HẰNG SỐ
// ---------------------------------------------------------------------
const ROLE = { ADMIN: 'Admin', NHAP: 'Nhập liệu', XEM: 'Xem' };
const KY_MO = 'Đang mở';
const KY_CHOT = 'Đã chốt';
const TT_AD = 'Đang áp dụng';
const TT_NGUNG = 'Ngừng áp dụng';
const TRAN_LUONG = 'Mức lương đóng tối đa';
const TRAN_DONG = 'Mức đóng tối đa';
const TRAN_KHONG = 'Không áp dụng';
const DT_NLD = 'NLĐ';
const DT_DN = 'DN';
const CO = 'Có';
const KHONG = 'Không';
const PQ_HD = 'Hoạt động';
const PQ_KHOA = 'Khóa';
const YCML_CHO = 'Chờ duyệt';
const YCML_DUYET = 'Đã duyệt';
const YCML_TUCHOI = 'Từ chối';
const YCML_KHOALAI = 'Đã khóa lại';
const NAM = 'Nam';
const NU = 'Nữ';
const GT_KHAC = 'Khác';

const LISTS = {
  role: [ROLE.ADMIN, ROLE.NHAP, ROLE.XEM],
  doiTuong: [DT_NLD, DT_DN],
  loaiTran: [TRAN_LUONG, TRAN_DONG, TRAN_KHONG],
  trangThai: [TT_AD, TT_NGUNG],
  coKhong: [CO, KHONG],
  pqTrangThai: [PQ_HD, PQ_KHOA],
  ycmlTrangThai: [YCML_CHO, YCML_DUYET, YCML_TUCHOI, YCML_KHOALAI],
  gioiTinh: [NAM, NU, GT_KHAC]
};

// Cột của hồ sơ nhân viên: [key, tiêu đề cột trên Sheet, kiểu]
const NV_COLS = [
  ['maNV', 'Mã NV', 'text'],
  ['hoTen', 'Họ và tên', 'text'],
  ['maBHXH', 'Mã số BHXH', 'text'],
  ['ngaySinh', 'Ngày sinh', 'date'],
  ['gioiTinh', 'Giới tính', 'text'],
  ['phongBan', 'Đơn vị_Phòng ban', 'text'],
  ['chucDanh', 'Chức danh', 'text'],
  ['ngayVao', 'Ngày vào làm', 'date'],
  ['ngayBHXH', 'Ngày bắt đầu BHXH', 'date'],
  ['ngayNghi', 'Ngày nghỉ việc', 'date'],
  ['thangDung', 'Tháng dừng đóng', 'month'],
  ['luongChinh', 'Mức lương chính', 'num'],
  ['pcKN', 'PC Kiêm nhiệm', 'num'],
  ['pcCV', 'PC Chức vụ', 'num'],
  ['pcDH', 'PC Độc hại', 'num'],
  ['pcKhac', 'PC Khác', 'num'],
  ['luongDong', 'Lương đóng BHXH', 'num'],
  ['maPL', 'Mã phân loại', 'text'],
  ['congDoan', 'Tham gia công đoàn', 'text'],
  ['emailQL', 'Email NV quản lý hồ sơ', 'text'],
  ['ghiChu', 'Ghi chú', 'text']
];

const T = {
  PB: { name: 'Phòng ban', cols: [
    ['ten', 'Đơn vị_Phòng ban', 'text'],
    ['ghiChu', 'Ghi chú', 'text']] },
  KHOAN: { name: 'Khoản trích đóng', cols: [
    ['id', 'ID', 'text'],
    ['ten', 'Tên khoản trích đóng', 'text'],
    ['ma', 'Mã nhận diện', 'text'],
    ['doiTuong', 'Đối tượng áp dụng', 'text'],
    ['tiLe', 'Tỉ lệ trích đóng mặc định (%)', 'pct'],
    ['loaiTran', 'Mức trần', 'text'],
    ['mucToiDa', 'Mức tối đa', 'num'],
    ['ngayHL', 'Ngày hiệu lực', 'date'],
    ['trangThai', 'Trạng thái', 'text'],
    ['chiDoanVien', 'Chỉ áp dụng đoàn viên công đoàn', 'text'],
    ['thuocCD', 'Thuộc quỹ Công đoàn', 'text'],
    ['ghiChu', 'Ghi chú', 'text']] },
  MAPL: { name: 'Mã phân loại', cols: [
    ['ma', 'Mã phân loại', 'text'],
    ['moTa', 'Mô tả', 'text'],
    ['trangThai', 'Trạng thái', 'text'],
    ['khoanNLD', 'Khoản trích đóng NLĐ', 'text'],
    ['khoanDN', 'Khoản trích đóng DN', 'text'],
    ['ghiChu', 'Ghi chú', 'text']] },
  NV: { name: 'Danh sách nhân viên', cols: NV_COLS },
  KY: { name: 'Kỳ BHXH', cols: [
    ['ky', 'Kỳ', 'month'],
    ['trangThai', 'Trạng thái', 'text'],
    ['ngayTao', 'Ngày tạo', 'text'],
    ['nguoiTao', 'Người tạo', 'text'],
    ['ngayTinh', 'Lần tính gần nhất', 'text'],
    ['nguoiTinh', 'Người tính', 'text'],
    ['ngayChot', 'Ngày chốt', 'text'],
    ['nguoiChot', 'Người chốt', 'text'],
    ['ghiChu', 'Ghi chú', 'text']] },
  DLKY: { name: 'Dữ liệu kỳ', cols: [['ky', 'Kỳ', 'month']].concat(NV_COLS) },
  KQ: { name: 'Kết quả tính', cols: [
    ['ky', 'Kỳ', 'month'],
    ['maNV', 'Mã NV', 'text'],
    ['hoTen', 'Họ và tên', 'text'],
    ['maBHXH', 'Mã số BHXH', 'text'],
    ['phongBan', 'Đơn vị_Phòng ban', 'text'],
    ['chucDanh', 'Chức danh', 'text'],
    ['maPL', 'Mã phân loại', 'text'],
    ['congDoan', 'Tham gia công đoàn', 'text'],
    ['luongDong', 'Lương đóng BHXH', 'num'],
    ['dong', 'Đóng trong kỳ', 'text'],
    ['tongNLD', 'Tổng NLĐ đóng', 'num'],
    ['tongDN', 'Tổng DN đóng', 'num'],
    ['tongCong', 'Tổng cộng', 'num'],
    ['canhBao', 'Cảnh báo', 'text'],
    ['emailQL', 'Email NV quản lý hồ sơ', 'text']] },
  TT: { name: 'Truy thu - Thoái thu', cols: [
    ['id', 'ID', 'text'],
    ['ky', 'Kỳ ghi nhận', 'month'],
    ['maNV', 'Mã NV', 'text'],
    ['hoTen', 'Họ và tên', 'text'],
    ['tuThang', 'Từ tháng', 'month'],
    ['denThang', 'Đến tháng', 'month'],
    ['soThang', 'Số tháng', 'num'],
    ['luongCu', 'Lương đóng cũ', 'num'],
    ['luongMoi', 'Lương đóng mới', 'num'],
    ['maPL', 'Mã phân loại', 'text'],
    ['congDoan', 'Tham gia công đoàn', 'text'],
    ['tienNLD', 'Chênh lệch NLĐ', 'num'],
    ['tienDN', 'Chênh lệch DN', 'num'],
    ['bhxhNLD', 'Chênh lệch BHXH NLĐ (không gồm Đoàn phí)', 'num'],
    ['bhxhDN', 'Chênh lệch BHXH DN (không gồm Kinh phí CĐ)', 'num'],
    ['dpcd', 'Chênh lệch Đoàn phí Công đoàn (NLĐ)', 'num'],
    ['dpcdGiuLai', 'Đoàn phí - Giữ lại cơ sở', 'num'],
    ['dpcdNop', 'Đoàn phí - Nộp Công đoàn VN', 'num'],
    ['kpcd', 'Chênh lệch Kinh phí Công đoàn (DN)', 'num'],
    ['kpcdGiuLai', 'Kinh phí - Giữ lại cơ sở', 'num'],
    ['kpcdNop', 'Kinh phí - Nộp Công đoàn VN', 'num'],
    ['chiTiet', 'Chi tiết theo khoản', 'text'],
    ['ghiChu', 'Ghi chú', 'text'],
    ['nguoiTao', 'Người tạo', 'text'],
    ['emailQL', 'Email NV quản lý hồ sơ', 'text']] },
  PQ: { name: 'Phân quyền', cols: [
    ['email', 'Email', 'text'],
    ['hoTen', 'Họ tên', 'text'],
    ['vaiTro', 'Vai trò', 'text'],
    ['trangThai', 'Trạng thái', 'text'],
    ['ghiChu', 'Ghi chú', 'text']] },
  LOG: { name: 'Nhật ký', cols: [
    ['thoiGian', 'Thời gian', 'text'],
    ['email', 'Người thực hiện', 'text'],
    ['hanhDong', 'Hành động', 'text'],
    ['chiTiet', 'Chi tiết', 'text']] },
  TLCD: { name: 'Tỉ lệ Công đoàn', cols: [
    ['id', 'ID', 'text'],
    ['tyLeGiuLaiNLD', 'Tỉ lệ giữ lại - Đoàn phí (NLĐ) (%)', 'pct'],
    ['tyLeGiuLaiDN', 'Tỉ lệ giữ lại - Kinh phí công đoàn (DN) (%)', 'pct'],
    ['ngayHL', 'Ngày hiệu lực', 'date'],
    ['ghiChu', 'Ghi chú', 'text']] },
  YCML: { name: 'Yêu cầu mở khóa NV', cols: [
    ['id', 'ID', 'text'],
    ['maNV', 'Mã NV', 'text'],
    ['hoTen', 'Họ và tên', 'text'],
    ['lyDo', 'Lý do', 'text'],
    ['nguoiYeuCau', 'Người yêu cầu', 'text'],
    ['thoiGianYC', 'Thời gian yêu cầu', 'text'],
    ['trangThai', 'Trạng thái', 'text'],
    ['nguoiDuyet', 'Người duyệt', 'text'],
    ['thoiGianDuyet', 'Thời gian duyệt', 'text'],
    ['ghiChu', 'Ghi chú', 'text']] }
};

const INFO_SHEET = 'Thông tin chung';
const INFO_FIELDS = [
  ['maCty', 'Mã công ty'],
  ['tenCty', 'Tên công ty'],
  ['mst', 'Mã số thuế'],
  ['diaChi', 'Địa chỉ'],
  ['vung', 'Vùng lương tối thiểu'],
  ['luongToiThieu', 'Mức lương tối thiểu vùng'],
  ['luongCoSo', 'Mức lương cơ sở']
];
const INFO_NUM_FIELDS = ['luongToiThieu', 'luongCoSo'];
const INFO_NUM_FMT = { luongToiThieu: '#,##0', luongCoSo: '#,##0' };

// ---------------------------------------------------------------------
// WEB APP & MENU
// ---------------------------------------------------------------------
function doGet() {
  return HtmlService.createTemplateFromFile('Index').evaluate()
    .setTitle('Quản lý BHXH')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function onOpen() {
  SpreadsheetApp.getUi().createMenu('BHXH')
    .addItem('1. Khởi tạo / cập nhật cấu trúc', 'khoiTaoCauTruc')
    .addItem('2. Tính lại cột "Lương đóng BHXH" (tab Danh sách nhân viên)', 'menuTinhLuongDong')
    .addSeparator()
    .addItem('Mở web app', 'menuMoWebApp')
    .addToUi();
}

function menuMoWebApp() {
  const url = ScriptApp.getService().getUrl();
  const html = url
    ? '<p style="font-family:Arial">Link web app:</p><p><a href="' + url + '" target="_blank">' + url + '</a></p>'
    : '<p style="font-family:Arial">Chưa triển khai web app. Vào Tiện ích mở rộng &gt; Apps Script &gt; Triển khai &gt; Tùy chọn triển khai mới &gt; Ứng dụng web.</p>';
  SpreadsheetApp.getUi().showModalDialog(HtmlService.createHtmlOutput(html).setWidth(520).setHeight(140), 'Web app BHXH');
}

function menuTinhLuongDong() {
  const d = load_(T.NV);
  d.rows.forEach(function (r) { update_(T.NV, r._row, { luongDong: luongDong_(r) }); });
  SpreadsheetApp.getActive().toast('Đã tính lại Lương đóng BHXH cho ' + d.rows.length + ' nhân viên.', 'BHXH');
}

// ---------------------------------------------------------------------
// KHỞI TẠO CẤU TRÚC
// ---------------------------------------------------------------------
function khoiTaoCauTruc() {
  const ss = activeSS_();
  ss.setSpreadsheetTimeZone('Asia/Ho_Chi_Minh');
  const me = (Session.getEffectiveUser().getEmail() || '').toLowerCase();

  // Thông tin chung (dạng 2 cột)
  let info = ss.getSheetByName(INFO_SHEET);
  if (!info) {
    info = ss.insertSheet(INFO_SHEET, 0);
    const vals = [['Thông tin', 'Giá trị']].concat(INFO_FIELDS.map(function (f) { return [f[1], '']; }));
    info.getRange(1, 1, vals.length, 2).setValues(vals);
    info.getRange('B2:B' + vals.length).setNumberFormat('@');
    info.getRange('B7:B8').setNumberFormat('#,##0');
    info.getRange('B6').setValue('Vùng I');
    info.getRange('B7').setValue(4960000);
    info.getRange('B8').setValue(2340000);
    info.getRange('C7').setValue('Số liệu mẫu – kiểm tra lại theo quy định hiện hành');
    styleHeader_(info, 2);
    info.setColumnWidth(1, 220); info.setColumnWidth(2, 360);
  }

  const created = {};
  Object.keys(T).forEach(function (k) { created[k] = ensureSheet_(T[k]); });

  if (created.PB) {
    append_(T.PB, ['Ban Giám đốc', 'Phòng Hành chính - Nhân sự', 'Phòng Kế toán'].map(function (x) { return { ten: x }; }));
  }
  if (created.KHOAN) {
    const hl = '2026-01-01', note = 'Số liệu mẫu – kiểm tra lại theo quy định hiện hành';
    const c1 = 46800000, c2 = 99200000;
    const sample = [
      ['Bảo hiểm xã hội (NLĐ)', 'BHXH_NLD', DT_NLD, 8, TRAN_LUONG, c1, KHONG, KHONG],
      ['Bảo hiểm y tế (NLĐ)', 'BHYT_NLD', DT_NLD, 1.5, TRAN_LUONG, c1, KHONG, KHONG],
      ['Bảo hiểm thất nghiệp (NLĐ)', 'BHTN_NLD', DT_NLD, 1, TRAN_LUONG, c2, KHONG, KHONG],
      ['Đoàn phí công đoàn (NLĐ)', 'DPCD_NLD', DT_NLD, 1, TRAN_DONG, 234000, CO, CO],
      ['Bảo hiểm xã hội (DN)', 'BHXH_DN', DT_DN, 17, TRAN_LUONG, c1, KHONG, KHONG],
      ['BH tai nạn lao động - BNN (DN)', 'BHTNLD_DN', DT_DN, 0.5, TRAN_LUONG, c1, KHONG, KHONG],
      ['Bảo hiểm y tế (DN)', 'BHYT_DN', DT_DN, 3, TRAN_LUONG, c1, KHONG, KHONG],
      ['Bảo hiểm thất nghiệp (DN)', 'BHTN_DN', DT_DN, 1, TRAN_LUONG, c2, KHONG, KHONG],
      ['Kinh phí công đoàn (DN)', 'KPCD_DN', DT_DN, 2, TRAN_LUONG, c1, KHONG, CO]
    ];
    append_(T.KHOAN, sample.map(function (s, i) {
      return { id: 'K' + (i + 1), ten: s[0], ma: s[1], doiTuong: s[2], tiLe: s[3], loaiTran: s[4], mucToiDa: s[5],
        ngayHL: hl, trangThai: TT_AD, chiDoanVien: s[6], thuocCD: s[7], ghiChu: note };
    }));
  }
  if (created.MAPL) {
    append_(T.MAPL, [
      { ma: 'CT', moTa: 'Nhân viên Việt Nam – HĐLĐ từ 1 tháng', trangThai: TT_AD,
        khoanNLD: 'BHXH_NLD; BHYT_NLD; BHTN_NLD; DPCD_NLD', khoanDN: 'BHXH_DN; BHTNLD_DN; BHYT_DN; BHTN_DN; KPCD_DN', ghiChu: 'Mẫu' },
      { ma: 'NN', moTa: 'Người nước ngoài', trangThai: TT_AD,
        khoanNLD: 'BHXH_NLD; BHYT_NLD; DPCD_NLD', khoanDN: 'BHXH_DN; BHTNLD_DN; BHYT_DN; KPCD_DN', ghiChu: 'Mẫu – kiểm tra lại' },
      { ma: 'HT', moTa: 'Người đang hưởng lương hưu', trangThai: TT_AD,
        khoanNLD: 'DPCD_NLD', khoanDN: 'BHTNLD_DN; KPCD_DN', ghiChu: 'Mẫu – kiểm tra lại' }
    ]);
  }
  if (created.PQ && me) {
    append_(T.PQ, [{ email: me, hoTen: 'Chủ sở hữu', vaiTro: ROLE.ADMIN, trangThai: PQ_HD, ghiChu: 'Tạo khi khởi tạo' }]);
  }
  if (created.TLCD) {
    append_(T.TLCD, [{ id: 'TL1', tyLeGiuLaiNLD: 40, tyLeGiuLaiDN: 40, ngayHL: '2026-01-01',
      ghiChu: 'Số liệu mẫu – kiểm tra lại quy định của Công đoàn cấp trên' }]);
  }

  // Dropdown (data validation)
  const v = function (t, title, list) {
    const sh = getSheet_(t), c = headerOf_(sh).indexOf(title) + 1;
    if (!c) return;
    sh.getRange(2, c, sh.getMaxRows() - 1, 1).setDataValidation(
      SpreadsheetApp.newDataValidation().requireValueInList(list, true).setAllowInvalid(true).build());
  };
  const vr = function (t, title, srcT) {
    const sh = getSheet_(t), c = headerOf_(sh).indexOf(title) + 1;
    const src = getSheet_(srcT);
    if (!c) return;
    sh.getRange(2, c, sh.getMaxRows() - 1, 1).setDataValidation(
      SpreadsheetApp.newDataValidation().requireValueInRange(src.getRange(2, 1, src.getMaxRows() - 1, 1), true)
        .setAllowInvalid(true).build());
  };
  v(T.KHOAN, 'Đối tượng áp dụng', LISTS.doiTuong);
  v(T.KHOAN, 'Mức trần', LISTS.loaiTran);
  v(T.KHOAN, 'Trạng thái', LISTS.trangThai);
  v(T.KHOAN, 'Chỉ áp dụng đoàn viên công đoàn', LISTS.coKhong);
  v(T.KHOAN, 'Thuộc quỹ Công đoàn', LISTS.coKhong);
  v(T.MAPL, 'Trạng thái', LISTS.trangThai);
  [T.NV, T.DLKY].forEach(function (t) {
    v(t, 'Tham gia công đoàn', LISTS.coKhong);
    v(t, 'Giới tính', LISTS.gioiTinh);
    vr(t, 'Mã phân loại', T.MAPL);
    vr(t, 'Đơn vị_Phòng ban', T.PB);
  });
  v(T.KY, 'Trạng thái', [KY_MO, KY_CHOT]);
  v(T.PQ, 'Vai trò', LISTS.role);
  v(T.PQ, 'Trạng thái', LISTS.pqTrangThai);
  v(T.YCML, 'Trạng thái', LISTS.ycmlTrangThai);

  try { ss.toast('Đã khởi tạo cấu trúc. Hãy kiểm tra các tab Thông tin chung, Khoản trích đóng, Mã phân loại.', 'BHXH', 8); } catch (e) { /* không có giao diện Sheet */ }
  return 'OK';
}

/** Lấy file Sheet chứa script; báo lỗi rõ ràng nếu script không gắn với Sheet */
function activeSS_() {
  const ss = SpreadsheetApp.getActive();
  if (!ss) {
    throw new Error('Script chưa gắn với Google Sheet. Hãy mở Google Sheet → Tiện ích mở rộng → Apps Script '
      + 'và dán code vào đó (không tạo project riêng tại script.google.com).');
  }
  return ss;
}

function ensureSheet_(t) {
  const ss = SpreadsheetApp.getActive();
  let sh = ss.getSheetByName(t.name);
  let isNew = false;
  if (!sh) {
    sh = ss.insertSheet(t.name);
    isNew = true;
  }
  let header = sh.getLastColumn() ? headerOf_(sh) : [];
  if (!header.filter(String).length) header = [];
  const missing = t.cols.map(function (c) { return c[1]; }).filter(function (h) { return header.indexOf(h) < 0; });
  if (missing.length) {
    header = header.concat(missing);
    sh.getRange(1, 1, 1, header.length).setValues([header]);
  }
  styleHeader_(sh, header.length);
  // định dạng cả cột
  const rows = sh.getMaxRows() - 1;
  t.cols.forEach(function (c) {
    const idx = header.indexOf(c[1]);
    if (idx >= 0) sh.getRange(2, idx + 1, rows, 1).setNumberFormat(fmtOf_(c[2]));
  });
  return isNew || sh.getLastRow() < 2;
}

function styleHeader_(sh, n) {
  sh.getRange(1, 1, 1, n).setFontWeight('bold').setBackground('#1f4e79').setFontColor('#ffffff').setWrap(true);
  sh.setFrozenRows(1);
}

// ---------------------------------------------------------------------
// TIỆN ÍCH NGÀY/SỐ
// ---------------------------------------------------------------------
function tz_() { return SpreadsheetApp.getActive().getSpreadsheetTimeZone() || Session.getScriptTimeZone(); }
function now_() { return Utilities.formatDate(new Date(), tz_(), 'dd/MM/yyyy HH:mm:ss'); }
function pad2_(n) { n = Number(n); return (n < 10 ? '0' : '') + n; }

/** Chuẩn hoá tháng về 'yyyy-MM' */
function normMonth_(v) {
  if (v === '' || v === null || v === undefined) return '';
  if (v instanceof Date) return Utilities.formatDate(v, tz_(), 'yyyy-MM');
  const s = String(v).trim();
  let m;
  if ((m = s.match(/^(\d{1,2})\/(\d{4})$/))) return m[2] + '-' + pad2_(m[1]);
  if ((m = s.match(/^(\d{4})-(\d{1,2})/))) return m[1] + '-' + pad2_(m[2]);
  if ((m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/))) return m[3] + '-' + pad2_(m[2]);
  return '';
}
/** Chuẩn hoá ngày về 'yyyy-MM-dd' */
function normDate_(v) {
  if (v === '' || v === null || v === undefined) return '';
  if (v instanceof Date) return Utilities.formatDate(v, tz_(), 'yyyy-MM-dd');
  const s = String(v).trim();
  let m;
  if ((m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/))) return m[3] + '-' + pad2_(m[2]) + '-' + pad2_(m[1]);
  if ((m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/))) return m[1] + '-' + pad2_(m[2]) + '-' + pad2_(m[3]);
  return '';
}
function monthDisp_(k) { return k ? k.slice(5, 7) + '/' + k.slice(0, 4) : ''; }
function dateDisp_(d) { return d ? d.slice(8, 10) + '/' + d.slice(5, 7) + '/' + d.slice(0, 4) : ''; }
function isoToDate_(s) { const p = s.split('-'); return new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2])); }
function nextMonth_(k) {
  let y = Number(k.slice(0, 4)), m = Number(k.slice(5, 7)) + 1;
  if (m > 12) { m = 1; y++; }
  return y + '-' + pad2_(m);
}
function monthRange_(a, b) {
  const out = [];
  let k = a;
  while (k && k <= b && out.length < 600) { out.push(k); k = nextMonth_(k); }
  return out;
}
/** Đọc số từ chuỗi, chấp nhận cả kiểu "1,234.5" và kiểu Việt Nam "1.234,5" / "1.234.567" */
/** Đọc số thập phân (dùng cho tỉ lệ %), chấp nhận cả kiểu "8.5" và kiểu Việt Nam "8,5" / "1.234,5". */
function num_(v) {
  if (typeof v === 'number') return isFinite(v) ? v : 0;
  if (v === null || v === undefined || v === '') return 0;
  let s = String(v).replace(/\s/g, '').trim();
  const lastDot = s.lastIndexOf('.'), lastComma = s.lastIndexOf(',');
  if (lastDot >= 0 && lastComma >= 0) {
    s = lastComma > lastDot ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '');
  } else if (lastComma >= 0) {
    const parts = s.split(',');
    s = (parts.length === 2 && parts[1].length <= 2) ? s.replace(',', '.') : s.replace(/,/g, '');
  } else if (lastDot >= 0 && s.split('.').length > 2) {
    s = s.replace(/\./g, ''); // nhiều dấu chấm -> dấu nhóm nghìn kiểu VN, không phải thập phân
  }
  const n = Number(s);
  return isFinite(n) ? n : 0;
}
/**
 * Đọc số tiền (luôn là số nguyên đồng trong app này, không có phần thập phân) – bỏ hết dấu chấm/phẩy/khoảng trắng
 * bất kể là dấu nhóm nghìn kiểu nào. Dùng cho lương, phụ cấp, mức tối đa… để không nhầm "253.000" thành 253.
 */
function moneyNum_(v) {
  if (typeof v === 'number') return isFinite(v) ? v : 0;
  if (v === null || v === undefined || v === '') return 0;
  const n = Number(String(v).replace(/[^\d-]/g, ''));
  return isFinite(n) ? n : 0;
}
/** Làm tròn đến đồng theo đúng nguyên tắc hàm ROUND (nửa làm tròn ra xa số 0), đúng cho cả số âm (thoái thu) */
function round0_(x) { return x < 0 ? -Math.round(-x) : Math.round(x); }
function fmtNum_(n) { return round0_(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
function fmtOf_(type) {
  return { text: '@', month: '@', date: 'dd/MM/yyyy', num: '#,##0', pct: '0.####' }[type] || '@';
}
function luongDong_(o) {
  const s = moneyNum_(o.luongChinh) + moneyNum_(o.pcKN) + moneyNum_(o.pcCV) + moneyNum_(o.pcDH) + moneyNum_(o.pcKhac);
  return s > 0 ? s : moneyNum_(o.luongDong);
}
function withLock_(fn) {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try { return fn(); } finally { lock.releaseLock(); }
}

// ---------------------------------------------------------------------
// LỚP TRUY CẬP BẢNG (SHEET)
// ---------------------------------------------------------------------
function getSheet_(t) {
  const sh = activeSS_().getSheetByName(t.name);
  if (!sh) throw new Error('Không tìm thấy tab "' + t.name + '". Hãy chạy menu BHXH > Khởi tạo / cập nhật cấu trúc.');
  return sh;
}
function headerOf_(sh) {
  const lc = sh.getLastColumn();
  return lc ? sh.getRange(1, 1, 1, lc).getValues()[0].map(function (h) { return String(h).trim(); }) : [];
}
function fromCell_(type, v) {
  switch (type) {
    case 'date': return normDate_(v);
    case 'month': return normMonth_(v);
    case 'num': return moneyNum_(v);
    case 'pct': return num_(v);
    default:
      if (v instanceof Date) return Utilities.formatDate(v, tz_(), 'dd/MM/yyyy HH:mm:ss');
      return String(v === null || v === undefined ? '' : v).trim();
  }
}
function toCell_(type, v) {
  if (v === undefined || v === null) return '';
  switch (type) {
    case 'date': { const s = normDate_(v); return s ? isoToDate_(s) : ''; }
    case 'month': { const s = normMonth_(v); return s ? monthDisp_(s) : ''; }
    case 'num': return v === '' ? '' : moneyNum_(v);
    case 'pct': return v === '' ? '' : num_(v);
    default: return String(v);
  }
}
function load_(t) {
  const sh = getSheet_(t);
  const header = headerOf_(sh);
  const lr = sh.getLastRow();
  const values = lr > 1 && header.length ? sh.getRange(2, 1, lr - 1, header.length).getValues() : [];
  const idx = {};
  t.cols.forEach(function (c) { idx[c[0]] = header.indexOf(c[1]); });
  const rows = [];
  values.forEach(function (v, i) {
    if (v.every(function (x) { return x === '' || x === null; })) return;
    const o = { _row: i + 2 };
    t.cols.forEach(function (c) {
      o[c[0]] = idx[c[0]] >= 0 ? fromCell_(c[2], v[idx[c[0]]]) : ((c[2] === 'num' || c[2] === 'pct') ? 0 : '');
    });
    rows.push(o);
  });
  return { sh: sh, header: header, rows: rows };
}
/**
 * Đọc dữ liệu kỳ (T.DLKY) CHỈ của 1 kỳ cụ thể, không đọc toàn bộ lịch sử các kỳ khác – dùng cho 2 đường
 * dẫn "nóng" nhất (mở tab Nhân viên theo kỳ, Lưu hồ sơ NV theo kỳ) để tránh phải tải lại toàn bộ dữ liệu
 * nhiều tháng/năm cộng dồn mỗi lần chỉ cần xem/sửa 1 kỳ – công ty dùng lâu, dữ liệu T.DLKY cộng dồn
 * nhiều kỳ thì load_(T.DLKY) đọc toàn bộ sẽ ngày càng chậm dù chỉ cần đúng 1 kỳ.
 * Cách làm: đọc riêng cột "Kỳ" trước (nhẹ, 1 cột), xác định đúng các dòng thuộc kỳ cần (không giả định
 * các dòng của 1 kỳ luôn liền nhau trên Sheet – đúng cả khi dữ liệu bị xáo trộn do sửa tay), rồi chỉ đọc
 * đầy đủ các dòng đó, ghép các dòng liền kề thành từng đoạn để giảm số lượt gọi getRange.
 */
/**
 * Số phiên bản dữ liệu T.DLKY – chỉ tăng khi có dòng được THÊM/XÓA (append_/deleteRows_), KHÔNG tăng khi
 * chỉ sửa nội dung 1 dòng đã có (update_) vì sửa nội dung không làm đổi vị trí dòng nào. Dùng để biết
 * chắc chắn khi nào "dòng nào thuộc kỳ nào" (xem getDlkyKyIndex_) vẫn còn đúng, không cần đọc lại.
 */
function dlkyVersion_() {
  try { return PropertiesService.getScriptProperties().getProperty('dlkyVer') || '0'; } catch (e) { return '0'; }
}
function bumpDlkyVersion_() {
  try {
    const p = PropertiesService.getScriptProperties();
    p.setProperty('dlkyVer', String((Number(p.getProperty('dlkyVer')) || 0) + 1));
  } catch (e) { /* bỏ qua lỗi PropertiesService, chỉ mất tác dụng cache, không ảnh hưởng dữ liệu */ }
}
/**
 * Dòng nào (chỉ số 0-based) trong T.DLKY thuộc về kỳ `ky` – đọc riêng cột "Kỳ" (nhẹ, 1 cột) rồi nhớ lại
 * trong CacheService (tối đa 30 phút) để các lần gọi tiếp theo không phải quét lại toàn bộ cột này, vốn
 * ngày càng dài ra khi công ty dùng app lâu (DLKY cộng dồn mọi kỳ từ trước tới nay). Cache được coi là
 * còn dùng được chỉ khi cả số phiên bản (dlkyVersion_) và tổng số dòng hiện tại đều khớp với lúc lưu –
 * tức là chưa có dòng nào bị thêm/xóa ở bất kỳ đâu trong T.DLKY kể từ lúc đó (chỉ sửa nội dung 1 dòng đã
 * có, như Lưu thông tin 1 nhân viên, KHÔNG làm mất cache).
 */
function getDlkyKyIndex_(sh, header, n, ky) {
  const kyColIdx = header.indexOf('Kỳ');
  if (kyColIdx < 0) return null; // phòng hờ thiếu cột Kỳ, để gọi nơi khác tự xử lý
  const ver = dlkyVersion_();
  const cacheKey = 'dlkyidx_' + ky;
  let cache = null;
  try { cache = CacheService.getScriptCache(); } catch (e) { cache = null; }
  if (cache) {
    try {
      const cached = cache.get(cacheKey);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed.ver === ver && parsed.n === n) return parsed.idx;
      }
    } catch (e) { /* bỏ qua lỗi đọc cache, tính lại như bình thường */ }
  }
  const kyVals = sh.getRange(2, kyColIdx + 1, n, 1).getValues();
  const matchIdx = [];
  kyVals.forEach(function (v, i) { if (normMonth_(v[0]) === ky) matchIdx.push(i); });
  if (cache) {
    try { cache.put(cacheKey, JSON.stringify({ ver: ver, n: n, idx: matchIdx }), 1800); } catch (e) { /* bỏ qua lỗi ghi cache */ }
  }
  return matchIdx;
}
function loadDLKYForKy_(ky) {
  const t = T.DLKY;
  const sh = getSheet_(t);
  const header = headerOf_(sh);
  const lr = sh.getLastRow();
  if (lr < 2 || !header.length) return [];
  const n = lr - 1;
  const matchIdx = getDlkyKyIndex_(sh, header, n, ky);
  if (matchIdx === null) return load_(t).rows.filter(function (r) { return r.ky === ky; }); // phòng hờ thiếu cột Kỳ
  if (!matchIdx.length) return [];
  const runs = [];
  let runStart = matchIdx[0], runLen = 1;
  for (let i = 1; i < matchIdx.length; i++) {
    if (matchIdx[i] === matchIdx[i - 1] + 1) { runLen++; } else { runs.push([runStart, runLen]); runStart = matchIdx[i]; runLen = 1; }
  }
  runs.push([runStart, runLen]);
  const idx = {};
  t.cols.forEach(function (c) { idx[c[0]] = header.indexOf(c[1]); });
  const rows = [];
  runs.forEach(function (run) {
    const startRow = 2 + run[0], len = run[1];
    const values = sh.getRange(startRow, 1, len, header.length).getValues();
    values.forEach(function (v, i) {
      if (v.every(function (x) { return x === '' || x === null; })) return;
      const o = { _row: startRow + i };
      t.cols.forEach(function (c) { o[c[0]] = idx[c[0]] >= 0 ? fromCell_(c[2], v[idx[c[0]]]) : ((c[2] === 'num' || c[2] === 'pct') ? 0 : ''); });
      rows.push(o);
    });
  });
  return rows;
}
function buildRow_(t, header, o, existing) {
  const row = existing ? existing.slice() : header.map(function () { return ''; });
  t.cols.forEach(function (c) {
    const i = header.indexOf(c[1]);
    if (i >= 0 && o[c[0]] !== undefined) row[i] = toCell_(c[2], o[c[0]]);
  });
  return row;
}
/** 'A', 'B', …, 'Z', 'AA', … cho số thứ tự cột (1-based) */
function colLetter_(col) {
  let s = '';
  while (col > 0) {
    const m = (col - 1) % 26;
    s = String.fromCharCode(65 + m) + s;
    col = Math.floor((col - 1) / 26);
  }
  return s;
}
/**
 * Đặt định dạng số liệu cho các cột của bảng t, dòng start..start+n-1. Chỉ có 4 định dạng khác nhau
 * (xem fmtOf_) nên nhóm các cột theo đúng định dạng rồi đặt 1 lần bằng getRangeList thay vì gọi
 * getRange().setNumberFormat() riêng cho TỪNG cột – mỗi lệnh gọi Spreadsheet đều tốn thời gian round-trip,
 * bảng nhiều cột (như Nhân viên/Dữ liệu kỳ) trước đây tốn hàng chục lệnh gọi chỉ để lưu 1 dòng.
 */
function formatRange_(t, sh, header, start, n) {
  const groups = {};
  t.cols.forEach(function (c) {
    const i = header.indexOf(c[1]);
    if (i < 0) return;
    const fmt = fmtOf_(c[2]);
    (groups[fmt] = groups[fmt] || []).push(i + 1);
  });
  Object.keys(groups).forEach(function (fmt) {
    const a1s = groups[fmt].map(function (col) {
      const L = colLetter_(col);
      return L + start + ':' + L + (start + n - 1);
    });
    sh.getRangeList(a1s).setNumberFormat(fmt);
  });
}
function ensureRows_(sh, need) {
  const max = sh.getMaxRows();
  if (need > max) sh.insertRowsAfter(max, need - max);
}
function append_(t, objs) {
  if (!objs || !objs.length) return;
  const sh = getSheet_(t);
  const header = headerOf_(sh);
  const rows = objs.map(function (o) { return buildRow_(t, header, o, null); });
  const start = sh.getLastRow() + 1;
  ensureRows_(sh, start + rows.length - 1);
  formatRange_(t, sh, header, start, rows.length);
  sh.getRange(start, 1, rows.length, header.length).setValues(rows);
  if (t === T.DLKY) bumpDlkyVersion_(); // thêm dòng -> "dòng nào thuộc kỳ nào" đã nhớ trước đó không còn đúng nữa
}
function update_(t, rowNum, o) {
  const sh = getSheet_(t);
  const header = headerOf_(sh);
  const rg = sh.getRange(rowNum, 1, 1, header.length);
  const ex = rg.getValues()[0];
  formatRange_(t, sh, header, rowNum, 1);
  rg.setValues([buildRow_(t, header, o, ex)]);
  // Chỉ sửa NỘI DUNG 1 dòng đã có (không thêm/xóa dòng) -> vị trí "dòng nào thuộc kỳ nào" không đổi,
  // không cần tăng dlkyVersion_ (giữ cache tra cứu kỳ vẫn dùng được, kể cả khi Lưu/sửa thông tin NV).
}
function deleteRows_(t, rowNums) {
  const sh = getSheet_(t);
  rowNums.slice().sort(function (a, b) { return b - a; }).forEach(function (r) { sh.deleteRow(r); });
  if (t === T.DLKY && rowNums.length) bumpDlkyVersion_();
}
function strip_(o) { const c = Object.assign({}, o); delete c._row; return c; }

function log_(user, action, detail) {
  try {
    append_(T.LOG, [{ thoiGian: now_(), email: user ? user.email : '', hanhDong: action, chiTiet: detail || '' }]);
  } catch (e) { /* bỏ qua lỗi ghi log */ }
}

// ---------------------------------------------------------------------
// NGƯỜI DÙNG & PHÂN QUYỀN
// ---------------------------------------------------------------------
function getUser_() {
  const email = (Session.getActiveUser().getEmail() || '').toLowerCase().trim();
  if (!email) {
    throw new Error('Không xác định được email đăng nhập. Hãy đăng nhập bằng tài khoản Google của tổ chức '
      + 'và triển khai web app với "Thực thi dưới dạng: Tôi", "Ai có quyền truy cập: Mọi người trong tổ chức".');
  }
  const rows = load_(T.PQ).rows;
  const r = rows.find(function (x) { return x.email.toLowerCase() === email; });
  if (r && r.trangThai !== PQ_KHOA && LISTS.role.indexOf(r.vaiTro) >= 0) {
    return { email: email, role: r.vaiTro, hoTen: r.hoTen || email };
  }
  // Chưa có Admin nào: chủ sở hữu script được coi là Admin
  const owner = (Session.getEffectiveUser().getEmail() || '').toLowerCase();
  const hasAdmin = rows.some(function (x) { return x.vaiTro === ROLE.ADMIN && x.trangThai !== PQ_KHOA; });
  if (!hasAdmin && email === owner) return { email: email, role: ROLE.ADMIN, hoTen: 'Chủ sở hữu' };
  throw new Error('Tài khoản ' + email + ' chưa được cấp quyền hoặc đã bị khóa. Vui lòng liên hệ Admin.');
}
function requireRole_(user, roles) {
  if (roles.indexOf(user.role) < 0) throw new Error('Bạn không có quyền thực hiện thao tác này (vai trò: ' + user.role + ').');
}
function canSee_(user, r) {
  if (user.role !== ROLE.NHAP) return true;
  return String(r.emailQL || '').toLowerCase() === user.email;
}

// ---------------------------------------------------------------------
// ĐỌC DANH MỤC
// ---------------------------------------------------------------------
function getInfo_() {
  const sh = SpreadsheetApp.getActive().getSheetByName(INFO_SHEET);
  const o = {};
  INFO_FIELDS.forEach(function (f) { o[f[0]] = ''; });
  if (!sh || sh.getLastRow() < 2) return o;
  sh.getRange(2, 1, sh.getLastRow() - 1, 2).getValues().forEach(function (r) {
    const f = INFO_FIELDS.find(function (x) { return x[1] === String(r[0]).trim(); });
    if (f) o[f[0]] = INFO_NUM_FIELDS.indexOf(f[0]) >= 0 ? moneyNum_(r[1]) : String(r[1]).trim();
  });
  return o;
}
function listKy_() {
  return load_(T.KY).rows.filter(function (r) { return r.ky; })
    .sort(function (a, b) { return a.ky < b.ky ? 1 : -1; });
}
function getKy_(ky) {
  const r = load_(T.KY).rows.find(function (x) { return x.ky === ky; });
  if (!r) throw new Error('Không tìm thấy kỳ ' + monthDisp_(ky));
  return r;
}
function requireOpen_(ky) {
  const k = getKy_(ky);
  if (k.trangThai === KY_CHOT) throw new Error('Kỳ ' + monthDisp_(ky) + ' đã chốt, không thể chỉnh sửa. Phát sinh cho tháng cũ hãy nhập Truy thu/Thoái thu ở kỳ đang mở.');
  return k;
}
/** "BHXH_NLD; BHYT_NLD=1.2" -> [{ma, tiLe}] */
function parseDS_(s) {
  return String(s || '').split(/[;\n]/).map(function (x) { return x.trim(); }).filter(String).map(function (x) {
    const p = x.split('=');
    const tl = p.length > 1 && String(p[1]).trim() !== '' ? num_(String(p[1]).replace(',', '.')) : null;
    return { ma: p[0].trim(), tiLe: tl };
  });
}
function maplMap_() {
  const m = {};
  load_(T.MAPL).rows.forEach(function (r) {
    if (!r.ma) return;
    const seen = {};
    r.ds = parseDS_(r.khoanNLD).concat(parseDS_(r.khoanDN)).filter(function (x) {
      if (seen[x.ma]) return false; seen[x.ma] = 1; return true;
    });
    m[r.ma] = r;
  });
  return m;
}
/** Chọn phiên bản khoản trích có hiệu lực trong tháng ky (ngày hiệu lực <= cuối tháng) */
function khoanHieuLuc_(rows, ky) {
  const end = ky + '-31';
  const best = {};
  rows.forEach(function (r) {
    if (!r.ma) return;
    const d = r.ngayHL || '0000-00-00';
    if (d > end) return;
    if (!best[r.ma] || d >= (best[r.ma].ngayHL || '0000-00-00')) best[r.ma] = r;
  });
  const m = {};
  Object.keys(best).forEach(function (c) { if (best[c].trangThai !== TT_NGUNG) m[c] = best[c]; });
  return m;
}
/** Chọn dòng tỉ lệ Công đoàn có hiệu lực trong tháng ky (ngày hiệu lực gần nhất nhưng <= cuối tháng) */
function tyLeGiuLaiHieuLuc_(rows, ky) {
  const end = ky + '-31';
  let best = null;
  rows.forEach(function (r) {
    const d = r.ngayHL || '0000-00-00';
    if (d > end) return;
    if (!best || d >= (best.ngayHL || '0000-00-00')) best = r;
  });
  return {
    nld: best ? Math.max(0, Math.min(100, num_(best.tyLeGiuLaiNLD))) : 0,
    dn: best ? Math.max(0, Math.min(100, num_(best.tyLeGiuLaiDN))) : 0
  };
}
function allCodes_(rows) {
  const nld = [], dn = [];
  rows.forEach(function (r) {
    if (!r.ma) return;
    const arr = r.doiTuong === DT_DN ? dn : nld;
    if (nld.indexOf(r.ma) < 0 && dn.indexOf(r.ma) < 0) arr.push(r.ma);
  });
  return nld.concat(dn);
}
function khoanTen_(rows) {
  const m = {};
  rows.slice().sort(function (a, b) { return (a.ngayHL || '') < (b.ngayHL || '') ? -1 : 1; })
    .forEach(function (r) { if (r.ma) m[r.ma] = { ma: r.ma, ten: r.ten, doiTuong: r.doiTuong }; });
  return m;
}

// ---------------------------------------------------------------------
// ENGINE TÍNH TOÁN
// ---------------------------------------------------------------------
function tienKhoan_(k, luong, tiLe) {
  let base = luong;
  const max = moneyNum_(k.mucToiDa);
  if (k.loaiTran === TRAN_LUONG && max > 0) base = Math.min(luong, max);
  let amt = base * tiLe / 100;
  if (k.loaiTran === TRAN_DONG && max > 0) amt = Math.min(amt, max);
  return round0_(amt); // làm tròn đến đồng theo nguyên tắc hàm ROUND, từng khoản
}
function tinhTheoPL_(luong, pl, kmap, congDoan) {
  const items = {};
  let nld = 0, dn = 0;
  (pl.ds || []).forEach(function (x) {
    const k = kmap[x.ma];
    if (!k) return;
    if (k.chiDoanVien === CO && congDoan !== CO) return;
    const rate = x.tiLe !== null ? x.tiLe : num_(k.tiLe);
    const a = tienKhoan_(k, luong, rate);
    items[x.ma] = a;
    if (k.doiTuong === DT_DN) dn += a; else nld += a;
  });
  return { items: items, nld: nld, dn: dn };
}
function tinhNV_(nv, ky, kmap, maplMap, ltt) {
  const luong = luongDong_(nv);
  const cb = [];
  let dong = true;
  if (!nv.ngayBHXH) { dong = false; cb.push('Chưa có ngày bắt đầu BHXH'); }
  else if (nv.ngayBHXH.slice(0, 7) > ky) { dong = false; cb.push('Chưa đến tháng bắt đầu BHXH'); }
  if (nv.thangDung && nv.thangDung <= ky) { dong = false; cb.push('Dừng đóng từ ' + monthDisp_(nv.thangDung)); }
  const pl = maplMap[nv.maPL];
  if (dong) {
    if (!nv.maPL) { dong = false; cb.push('Chưa có mã phân loại'); }
    else if (!pl) { dong = false; cb.push('Mã phân loại "' + nv.maPL + '" không tồn tại'); }
    else if (pl.trangThai === TT_NGUNG) { dong = false; cb.push('Mã phân loại "' + nv.maPL + '" đã ngừng áp dụng'); }
  }
  if (dong && luong <= 0) cb.push('Lương đóng BHXH = 0');
  if (dong && ltt > 0 && luong > 0 && luong < ltt) cb.push('Lương đóng thấp hơn lương tối thiểu vùng (' + fmtNum_(ltt) + ')');
  if (nv.ngayNghi && !nv.thangDung) cb.push('Có ngày nghỉ việc nhưng chưa nhập tháng dừng đóng');
  let r = { items: {}, nld: 0, dn: 0 };
  if (dong) r = tinhTheoPL_(luong, pl, kmap, nv.congDoan);
  return { luong: luong, dong: dong, items: r.items, nld: r.nld, dn: r.dn, canhBao: cb };
}
/**
 * Tính chênh lệch truy thu/thoái thu, tách riêng BHXH NLĐ / BHXH DN / Đoàn phí CĐ (NLĐ) / Kinh phí CĐ (DN)
 * vì các khoản này hạch toán chi trả khác nhau. Đoàn phí và Kinh phí CĐ còn được tách tiếp thành phần
 * giữ lại cơ sở / nộp Công đoàn Việt Nam, theo đúng tỉ lệ có hiệu lực của TỪNG THÁNG trong khoảng truy thu.
 * cdCodes: {ma: true} các khoản "Thuộc quỹ Công đoàn". ten: map mã khoản -> {doiTuong}. tlRows: rows tab Tỉ lệ Công đoàn.
 */
function tinhTruyThu_(r, ctxFn, maplMap, cdCodes, ten, tlRows) {
  const pl = maplMap[r.maPL];
  const months = monthRange_(r.tuThang, r.denThang);
  if (!pl) {
    return {
      soThang: months.length, nld: 0, dn: 0, bhxhNLD: 0, bhxhDN: 0,
      dpcd: 0, dpcdGiuLai: 0, dpcdNop: 0, kpcd: 0, kpcdGiuLai: 0, kpcdNop: 0,
      chiTiet: 'Mã phân loại không hợp lệ'
    };
  }
  const sum = {};
  let nld = 0, dn = 0, dpcd = 0, dpcdNop = 0, kpcd = 0, kpcdNop = 0;
  months.forEach(function (m) {
    const km = ctxFn(m);
    const a = tinhTheoPL_(moneyNum_(r.luongMoi), pl, km, r.congDoan);
    const b = tinhTheoPL_(moneyNum_(r.luongCu), pl, km, r.congDoan);
    const codes = {};
    Object.keys(a.items).concat(Object.keys(b.items)).forEach(function (c) { codes[c] = 1; });
    let mDpcd = 0, mKpcd = 0;
    Object.keys(codes).forEach(function (c) {
      const diff = (a.items[c] || 0) - (b.items[c] || 0);
      sum[c] = (sum[c] || 0) + diff;
      if (cdCodes && cdCodes[c]) { if ((ten[c] || {}).doiTuong === DT_DN) mKpcd += diff; else mDpcd += diff; }
    });
    dpcd += mDpcd; kpcd += mKpcd;
    if (tlRows) {
      // Tính phần nộp Công đoàn Việt Nam trước và làm tròn, phần giữ lại cơ sở = phần còn lại (không làm tròn riêng)
      const tl = tyLeGiuLaiHieuLuc_(tlRows, m);
      dpcdNop += round0_(mDpcd * (100 - tl.nld) / 100);
      kpcdNop += round0_(mKpcd * (100 - tl.dn) / 100);
    }
    nld += a.nld - b.nld;
    dn += a.dn - b.dn;
  });
  return {
    soThang: months.length, nld: nld, dn: dn, bhxhNLD: nld - dpcd, bhxhDN: dn - kpcd,
    dpcd: dpcd, dpcdGiuLai: dpcd - dpcdNop, dpcdNop: dpcdNop,
    kpcd: kpcd, kpcdGiuLai: kpcd - kpcdNop, kpcdNop: kpcdNop,
    chiTiet: Object.keys(sum).filter(function (c) { return sum[c]; }).map(function (c) { return c + ': ' + fmtNum_(sum[c]); }).join('; ')
  };
}
function ctxFactory_() {
  const khoanRows = load_(T.KHOAN).rows;
  const cache = {};
  return { khoanRows: khoanRows, fn: function (m) { return cache[m] || (cache[m] = khoanHieuLuc_(khoanRows, m)); } };
}

// ----- Bảng kết quả (cột khoản trích sinh động theo mã) -----
function kqBaseTitles_() { return T.KQ.cols.map(function (c) { return c[1]; }); }
function loadKQAll_() {
  const sh = getSheet_(T.KQ);
  const header = headerOf_(sh);
  const base = kqBaseTitles_();
  const codes = header.filter(function (h) { return h && base.indexOf(h) < 0; });
  const lr = sh.getLastRow();
  const vals = lr > 1 && header.length ? sh.getRange(2, 1, lr - 1, header.length).getValues() : [];
  const rows = [];
  vals.forEach(function (v) {
    if (v.every(function (x) { return x === ''; })) return;
    const o = {};
    T.KQ.cols.forEach(function (c) { const i = header.indexOf(c[1]); o[c[0]] = i >= 0 ? fromCell_(c[2], v[i]) : ''; });
    o.items = {};
    codes.forEach(function (c) { const n = moneyNum_(v[header.indexOf(c)]); if (n) o.items[c] = n; });
    rows.push(o);
  });
  return { codes: codes, rows: rows };
}
function writeKQ_(ky, out, codes) {
  const sh = getSheet_(T.KQ);
  let header = headerOf_(sh);
  if (!header.filter(String).length) header = kqBaseTitles_();
  const oldLen = header.length;
  codes.forEach(function (c) { if (header.indexOf(c) < 0) header.push(c); });
  const lr = sh.getLastRow();
  const old = lr > 1 ? sh.getRange(2, 1, lr - 1, oldLen).getValues() : [];
  const kyCol = header.indexOf('Kỳ');
  const keep = old.filter(function (v) {
    return v.some(function (x) { return x !== ''; }) && normMonth_(v[kyCol]) !== ky;
  }).map(function (v) {
    const a = v.slice();
    while (a.length < header.length) a.push('');
    a[kyCol] = monthDisp_(normMonth_(a[kyCol]));
    return a;
  });
  const fresh = out.map(function (o) {
    const row = buildRow_(T.KQ, header, o, null);
    codes.forEach(function (c) { row[header.indexOf(c)] = o.dong === CO ? (o.items[c] || 0) : ''; });
    return row;
  });
  const all = keep.concat(fresh).sort(function (a, b) {
    const x = normMonth_(a[kyCol]), y = normMonth_(b[kyCol]);
    return x < y ? -1 : (x > y ? 1 : 0);
  });
  if (lr > 1) sh.getRange(2, 1, lr - 1, Math.max(sh.getLastColumn(), 1)).clearContent();
  sh.getRange(1, 1, 1, header.length).setValues([header]);
  styleHeader_(sh, header.length);
  if (all.length) {
    ensureRows_(sh, all.length + 1);
    formatRange_(T.KQ, sh, header, 2, all.length);
    codes.forEach(function (c) { sh.getRange(2, header.indexOf(c) + 1, all.length, 1).setNumberFormat('#,##0'); });
    sh.getRange(2, 1, all.length, header.length).setValues(all);
  }
}

// ---------------------------------------------------------------------
// API: KHỞI ĐỘNG
// ---------------------------------------------------------------------
function apiBootstrap() {
  // Lần đầu chủ sở hữu mở web app mà chưa có cấu trúc -> tự khởi tạo
  const ss = activeSS_();
  const me = (Session.getActiveUser().getEmail() || '').toLowerCase();
  const owner = (Session.getEffectiveUser().getEmail() || '').toLowerCase();
  if (!ss.getSheetByName(T.PQ.name) && me && me === owner) khoiTaoCauTruc();
  const user = getUser_();
  return {
    user: user,
    info: getInfo_(),
    kys: listKy_(),
    khoan: load_(T.KHOAN).rows,
    mapl: load_(T.MAPL).rows,
    tlcd: load_(T.TLCD).rows,
    phongBan: load_(T.PB).rows.map(function (r) { return r.ten; }).filter(String),
    lists: LISTS,
    today: Utilities.formatDate(new Date(), tz_(), 'yyyy-MM')
  };
}

// ---------------------------------------------------------------------
// API: KỲ BHXH
// ---------------------------------------------------------------------
function apiListKy() { getUser_(); return listKy_(); }

/**
 * Bổ sung vào kỳ những NV có trong hồ sơ gốc nhưng chưa có trong kỳ này (NV mới, hoặc NV thử việc đã vào làm
 * nhưng trước đó bị bỏ sót). Chỉ loại NV có Ngày vào làm SAU tháng của kỳ (chưa thực sự vào làm ở kỳ đó);
 * KHÔNG loại theo Ngày bắt đầu BHXH — NV chưa đến ngày đóng vẫn phải có mặt trong kỳ với trạng thái "Không đóng"
 * (tinhNV_ tự đánh cảnh báo "Chưa đến tháng bắt đầu BHXH"), để thấy đầy đủ trong các báo cáo.
 */
function themTuHoSoVaoKy_(ky, have) {
  const themMoi = [];
  load_(T.NV).rows.forEach(function (m) {
    if (!m.maNV || have[m.maNV]) return;
    if (m.ngayVao && m.ngayVao.slice(0, 7) > ky) return;
    const o = strip_(m);
    o.ky = ky;
    o.luongDong = luongDong_(o);
    themMoi.push(o);
    have[m.maNV] = 1;
  });
  if (themMoi.length) append_(T.DLKY, themMoi);
  return themMoi.length;
}

function apiTaoKy(ky) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  ky = normMonth_(ky);
  if (!ky) throw new Error('Kỳ không hợp lệ.');
  return withLock_(function () {
    const kys = listKy_();
    if (kys.some(function (k) { return k.ky === ky; })) throw new Error('Kỳ ' + monthDisp_(ky) + ' đã tồn tại.');
    if (kys.length && ky < kys[0].ky) throw new Error('Chỉ được tạo kỳ sau kỳ mới nhất (' + monthDisp_(kys[0].ky) + ').');
    const src = kys.length ? kys[0].ky : null;
    const base = src ? load_(T.DLKY).rows.filter(function (r) { return r.ky === src; }) : [];
    const have = {};
    base.forEach(function (r) { have[r.maNV] = 1; });
    const copy = base.filter(function (r) { return !r.thangDung || r.thangDung > ky; }).map(function (r) {
      const o = strip_(r);
      o.ky = ky;
      o.luongDong = luongDong_(o);
      return o;
    });
    append_(T.DLKY, copy);
    append_(T.KY, [{ ky: ky, trangThai: KY_MO, ngayTao: now_(), nguoiTao: user.email }]);
    const themTuHoSo = themTuHoSoVaoKy_(ky, have);
    const nguon = src ? 'kỳ ' + monthDisp_(src) : 'tab Danh sách nhân viên';
    log_(user, 'Tạo kỳ', monthDisp_(ky) + ' – ' + (copy.length + themTuHoSo) + ' NV, nguồn: ' + nguon);
    return { ky: ky, soNV: copy.length + themTuHoSo, nguon: nguon, themTuHoSo: src ? themTuHoSo : 0 };
  });
}

function apiTinhKy(ky) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN, ROLE.NHAP]);
  ky = normMonth_(ky);
  return withLock_(function () {
    requireOpen_(ky);
    const res = tinhKy_(ky, user);
    log_(user, 'Tính kỳ', monthDisp_(ky) + ' – ' + res.soDong + '/' + res.soNV + ' NV đóng');
    return res;
  });
}

function tinhKy_(ky, user) {
  const info = getInfo_();
  const ctx = ctxFactory_();
  const maplMap = maplMap_();
  const kmap = ctx.fn(ky);
  const have = {};
  load_(T.DLKY).rows.forEach(function (r) { if (r.ky === ky) have[r.maNV] = 1; });
  themTuHoSoVaoKy_(ky, have); // tự bổ sung NV mới/thử việc còn thiếu trong kỳ này từ hồ sơ gốc
  const nvs = load_(T.DLKY).rows.filter(function (r) { return r.ky === ky; });
  const codes = allCodes_(ctx.khoanRows);
  let tongNLD = 0, tongDN = 0, soDong = 0, soCB = 0;
  const out = nvs.map(function (nv) {
    const r = tinhNV_(nv, ky, kmap, maplMap, moneyNum_(info.luongToiThieu));
    if (r.dong) { soDong++; tongNLD += r.nld; tongDN += r.dn; }
    if (r.canhBao.length) soCB++;
    return {
      ky: ky, maNV: nv.maNV, hoTen: nv.hoTen, maBHXH: nv.maBHXH, phongBan: nv.phongBan, chucDanh: nv.chucDanh,
      maPL: nv.maPL, congDoan: nv.congDoan, luongDong: r.luong, dong: r.dong ? CO : KHONG,
      tongNLD: r.nld, tongDN: r.dn, tongCong: r.nld + r.dn, canhBao: r.canhBao.join('; '), emailQL: nv.emailQL,
      items: r.items
    };
  });
  writeKQ_(ky, out, codes);

  const cdCodes = congDoanCodes_(ctx.khoanRows);
  const ten = khoanTen_(ctx.khoanRows);
  const tlRows = load_(T.TLCD).rows;
  let ttNLD = 0, ttDN = 0;
  load_(T.TT).rows.filter(function (r) { return r.ky === ky; }).forEach(function (r) {
    const c = tinhTruyThu_(r, ctx.fn, maplMap, cdCodes, ten, tlRows);
    ttNLD += c.nld; ttDN += c.dn;
    update_(T.TT, r._row, {
      soThang: c.soThang, tienNLD: c.nld, tienDN: c.dn, bhxhNLD: c.bhxhNLD, bhxhDN: c.bhxhDN,
      dpcd: c.dpcd, dpcdGiuLai: c.dpcdGiuLai, dpcdNop: c.dpcdNop, kpcd: c.kpcd, kpcdGiuLai: c.kpcdGiuLai, kpcdNop: c.kpcdNop,
      chiTiet: c.chiTiet
    });
  });
  update_(T.KY, getKy_(ky)._row, { ngayTinh: now_(), nguoiTinh: user.email });
  return { ky: ky, soNV: nvs.length, soDong: soDong, soCanhBao: soCB, tongNLD: tongNLD, tongDN: tongDN, ttNLD: ttNLD, ttDN: ttDN };
}

function apiChotKy(ky) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  ky = normMonth_(ky);
  return withLock_(function () {
    requireOpen_(ky);
    const res = tinhKy_(ky, user); // tính lại lần cuối trước khi chốt
    update_(T.KY, getKy_(ky)._row, { trangThai: KY_CHOT, ngayChot: now_(), nguoiChot: user.email });
    log_(user, 'Chốt kỳ', monthDisp_(ky));
    return res;
  });
}

/** Mở lại một kỳ đã chốt để sửa/tính lại. Không giới hạn ở kỳ mới nhất (trường hợp khẩn cấp có thể cần sửa kỳ cũ). */
function apiMoLaiKy(ky) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  ky = normMonth_(ky);
  return withLock_(function () {
    const k = getKy_(ky);
    if (k.trangThai !== KY_CHOT) throw new Error('Kỳ ' + monthDisp_(ky) + ' đang mở, không cần mở lại.');
    update_(T.KY, k._row, { trangThai: KY_MO, ngayChot: '', nguoiChot: '' });
    log_(user, 'Mở lại kỳ', monthDisp_(ky));
    return { ky: ky };
  });
}

/**
 * Xóa hẳn một kỳ (chỉ cho phép xóa kỳ MỚI NHẤT, để tránh làm đứt quãng dữ liệu của các kỳ sau).
 * Xóa dữ liệu NV của kỳ (Dữ liệu kỳ), kết quả tính (Kết quả tính) và các dòng Truy thu ghi nhận trong kỳ đó.
 */
function apiXoaKy(ky) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  ky = normMonth_(ky);
  return withLock_(function () {
    const kys = listKy_(); // mới nhất trước
    if (!kys.length || kys[0].ky !== ky) throw new Error('Chỉ được xóa kỳ mới nhất (' + (kys.length ? monthDisp_(kys[0].ky) : '') + ').');
    const k = getKy_(ky);
    const dlkyRows = load_(T.DLKY).rows.filter(function (r) { return r.ky === ky; });
    if (dlkyRows.length) deleteRows_(T.DLKY, dlkyRows.map(function (r) { return r._row; }));
    const ttRows = load_(T.TT).rows.filter(function (r) { return r.ky === ky; });
    if (ttRows.length) deleteRows_(T.TT, ttRows.map(function (r) { return r._row; }));
    writeKQ_(ky, [], allCodes_(ctxFactory_().khoanRows)); // xóa kết quả tính của kỳ (giữ nguyên các kỳ khác)
    deleteRows_(T.KY, [k._row]);
    log_(user, 'Xóa kỳ', monthDisp_(ky));
    return true;
  });
}

// ---------------------------------------------------------------------
// API: NHÂN VIÊN
// ky = '' nghĩa là làm việc trên hồ sơ gốc (tab Danh sách nhân viên)
// ---------------------------------------------------------------------
// Nhân viên đã nghỉ việc (có Tháng dừng đóng <= kỳ/hiện tại) coi như bị khóa với vai trò Nhập liệu
function nvDaKhoa_(nv, ky) {
  if (!nv || !nv.thangDung) return false;
  return nv.thangDung <= (ky || todayStr_().slice(0, 7));
}
function ycmlRowsCuaNV_(maNV) {
  return load_(T.YCML).rows.filter(function (r) { return r.maNV === maNV; })
    .sort(function (a, b) { return a.thoiGianYC < b.thoiGianYC ? 1 : -1; });
}
// true nếu yêu cầu mở khóa gần nhất của NV đã được Admin duyệt (và chưa bị khóa lại)
function nvDangMoKhoa_(maNV) {
  const rows = ycmlRowsCuaNV_(maNV);
  return !!(rows.length && rows[0].trangThai === YCML_DUYET);
}
/**
 * {maNV -> yêu cầu mở khóa gần nhất} cho TOÀN BỘ NV, đọc tab "Yêu cầu mở khóa NV" đúng 1 lần – dùng khi
 * cần biết trạng thái mở khóa của nhiều NV cùng lúc (vd. liệt kê cả danh sách ở apiNhanVien), để tránh
 * gọi ycmlRowsCuaNV_/nvDangMoKhoa_ lặp lại cho từng NV (mỗi lần gọi là 1 lần đọc lại cả Sheet từ đầu).
 */
function ycmlLatestMap_() {
  const groups = {};
  load_(T.YCML).rows.forEach(function (r) {
    if (!r.maNV) return;
    (groups[r.maNV] = groups[r.maNV] || []).push(r);
  });
  const m = {};
  Object.keys(groups).forEach(function (maNV) {
    groups[maNV].sort(function (a, b) { return a.thoiGianYC < b.thoiGianYC ? 1 : -1; });
    m[maNV] = groups[maNV][0];
  });
  return m;
}
function nvCoTheSua_(nv, ky, user) {
  if (user.role !== ROLE.NHAP) return true;
  if (!nvDaKhoa_(nv, ky)) return true;
  return nvDangMoKhoa_(nv.maNV);
}
function nvKhoaMsg_(nv) {
  return 'Nhân viên "' + nv.maNV + '" đã nghỉ việc (dừng đóng từ ' + monthDisp_(nv.thangDung)
    + '), hồ sơ đã bị khóa. Hãy gửi yêu cầu mở khóa để Admin xét duyệt.';
}

function apiNhanVien(ky) {
  const t0 = Date.now();
  const user = getUser_();
  const t1 = Date.now();
  ky = normMonth_(ky);
  let rows, trangThai = '', editable;
  if (ky) {
    const k = getKy_(ky);
    trangThai = k.trangThai;
    rows = loadDLKYForKy_(ky);
    editable = k.trangThai !== KY_CHOT;
  } else {
    rows = load_(T.NV).rows;
    editable = true;
  }
  const t2 = Date.now();
  editable = editable && user.role !== ROLE.XEM;
  const ycmlMap = ycmlLatestMap_(); // đọc tab Yêu cầu mở khóa NV đúng 1 lần cho cả danh sách, không lặp lại theo từng NV
  const t3 = Date.now();
  rows = rows.filter(function (r) { return canSee_(user, r); }).map(function (r) {
    r.luongDong = luongDong_(r);
    r.khoa = nvDaKhoa_(r, ky);
    r.moKhoa = r.khoa && !!(ycmlMap[r.maNV] && ycmlMap[r.maNV].trangThai === YCML_DUYET);
    return r;
  });
  const t4 = Date.now();
  // __t: thời gian (ms) từng bước, chỉ để chẩn đoán tốc độ – App.html tự in ra Console (F12) nếu có,
  // không ảnh hưởng gì tới dữ liệu hay giao diện.
  return { ky: ky, trangThai: trangThai, editable: editable, rows: rows,
    __t: { xacThucNguoiDung: t1 - t0, docDuLieuNV: t2 - t1, docYeuCauMoKhoa: t3 - t2, xuLy: t4 - t3, tong: t4 - t0 } };
}

// ---------------------------------------------------------------------
// API: YÊU CẦU MỞ KHÓA NHÂN VIÊN NGHỈ VIỆC
// ---------------------------------------------------------------------
function apiYeuCauMoKhoa(maNV, lyDo) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN, ROLE.NHAP]);
  lyDo = String(lyDo || '').trim();
  if (!lyDo) throw new Error('Vui lòng ghi lý do yêu cầu mở khóa.');
  return withLock_(function () {
    const nv = load_(T.NV).rows.find(function (r) { return r.maNV === maNV; });
    if (!nv) throw new Error('Không tìm thấy NV "' + maNV + '".');
    if (!canSee_(user, nv)) throw new Error('Bạn không quản lý hồ sơ NV này.');
    append_(T.YCML, [{
      id: 'YC' + new Date().getTime(), maNV: maNV, hoTen: nv.hoTen, lyDo: lyDo,
      nguoiYeuCau: user.email, thoiGianYC: now_(), trangThai: YCML_CHO
    }]);
    log_(user, 'Yêu cầu mở khóa NV', maNV + ' ' + nv.hoTen + ' – ' + lyDo);
    return true;
  });
}
function apiListYeuCauMoKhoa() {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN, ROLE.NHAP]);
  let rows = load_(T.YCML).rows;
  if (user.role !== ROLE.ADMIN) rows = rows.filter(function (r) { return r.nguoiYeuCau === user.email; });
  return rows.sort(function (a, b) { return a.thoiGianYC < b.thoiGianYC ? 1 : -1; });
}
function apiDuyetYeuCauMoKhoa(id, duyet) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  return withLock_(function () {
    const r = load_(T.YCML).rows.find(function (x) { return x.id === id; });
    if (!r) throw new Error('Không tìm thấy yêu cầu.');
    const trangThai = duyet ? YCML_DUYET : YCML_TUCHOI;
    update_(T.YCML, r._row, { trangThai: trangThai, nguoiDuyet: user.email, thoiGianDuyet: now_() });
    log_(user, duyet ? 'Duyệt mở khóa NV' : 'Từ chối mở khóa NV', r.maNV + ' ' + r.hoTen);
    return true;
  });
}
function apiKhoaLaiNV(maNV) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  return withLock_(function () {
    const rows = ycmlRowsCuaNV_(maNV);
    if (!rows.length || rows[0].trangThai !== YCML_DUYET) throw new Error('Nhân viên này chưa được mở khóa.');
    update_(T.YCML, rows[0]._row, { trangThai: YCML_KHOALAI, nguoiDuyet: user.email, thoiGianDuyet: now_() });
    log_(user, 'Khóa lại NV', maNV);
    return true;
  });
}

function apiSaveNV(ky, o, isNew) {
  const t0 = Date.now();
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN, ROLE.NHAP]);
  ky = normMonth_(ky);
  o = cleanNV_(o, user);
  const t1 = Date.now();
  return withLock_(function () {
    const t2 = Date.now();
    const kys = listKy_();
    const latest = kys.length ? kys[0].ky : '';
    // Đọc tab Danh sách nhân viên đúng 1 lần (nếu cần) và dùng lại, thay vì load_(T.NV) 2 lần riêng biệt
    // cho việc kiểm tra khóa và việc tìm dòng để cập nhật hồ sơ gốc.
    const needNV = !isNew || !ky || ky >= latest;
    const nvRows = needNV ? load_(T.NV).rows : null;
    const t3 = Date.now();
    if (!isNew) {
      const hoSo = nvRows.find(function (r) { return r.maNV === o.maNV; });
      if (hoSo && !nvCoTheSua_(hoSo, ky, user)) throw new Error(nvKhoaMsg_(hoSo));
    }
    const t4 = Date.now();
    if (ky) {
      requireOpen_(ky);
      const ex = loadDLKYForKy_(ky).find(function (r) { return r.maNV === o.maNV; });
      saveOne_(T.DLKY, ex, Object.assign({ ky: ky }, o), isNew, user);
    }
    const t5 = Date.now();
    // Cập nhật hồ sơ gốc nếu sửa ở kỳ mới nhất hoặc sửa trực tiếp hồ sơ gốc
    if (!ky || ky >= latest) {
      const ex2 = nvRows.find(function (r) { return r.maNV === o.maNV; });
      if (!ky) saveOne_(T.NV, ex2, o, isNew, user);
      else if (ex2) update_(T.NV, ex2._row, o);
      else append_(T.NV, [o]);
    }
    const t6 = Date.now();
    log_(user, isNew ? 'Thêm NV' : 'Sửa NV', (ky ? 'Kỳ ' + monthDisp_(ky) : 'Hồ sơ gốc') + ' – ' + o.maNV + ' ' + o.hoTen);
    const t7 = Date.now();
    // __t: thời gian (ms) từng bước, chỉ để chẩn đoán tốc độ – App.html tự in ra Console (F12) nếu có.
    return { ok: true, __t: {
      xacThucVaChuan: t1 - t0, chiLock: t2 - t1, docDanhSachNV: t3 - t2, kiemTraKhoa: t4 - t3,
      luuTheoKy: t5 - t4, luuHoSoGoc: t6 - t5, ghiNhatKy: t7 - t6, tong: t7 - t0
    } };
  });
}
function saveOne_(t, ex, o, isNew, user) {
  if (isNew) {
    if (ex) throw new Error('Mã NV "' + o.maNV + '" đã tồn tại.');
    append_(t, [o]);
  } else {
    if (!ex) throw new Error('Không tìm thấy NV "' + o.maNV + '".');
    if (!canSee_(user, ex)) throw new Error('Bạn không quản lý hồ sơ NV này.');
    update_(t, ex._row, o);
  }
}
/** {tên đã chuẩn hoá (thường, bỏ khoảng trắng dư) -> tên đúng theo danh mục Phòng ban} */
function pbMap_() {
  const m = {};
  load_(T.PB).rows.forEach(function (r) { if (r.ten) m[normHeader_(r.ten)] = r.ten; });
  return m;
}
/** Kiểm tra & chuẩn hoá giá trị "Đơn vị_Phòng ban" theo đúng danh mục đã cấu hình; báo lỗi nếu không khớp. */
function checkPhongBan_(v, pbMapObj) {
  if (!v) return '';
  const pbm = pbMapObj || pbMap_();
  const hit = pbm[normHeader_(v)];
  if (!hit) throw new Error('Đơn vị_Phòng ban "' + v + '" không có trong danh mục. Vào Thiết lập → Phòng ban để thêm trước khi nhập.');
  return hit;
}
/** Kiểm tra & chuẩn hoá giá trị "Tham gia công đoàn" (chỉ nhận Có/Không); báo lỗi nếu không khớp. */
function checkCongDoan_(v) {
  if (!v) return KHONG;
  const s = normHeader_(v);
  if (s === normHeader_(CO)) return CO;
  if (s === normHeader_(KHONG)) return KHONG;
  throw new Error('Tham gia công đoàn "' + v + '" không hợp lệ (chỉ nhận "' + CO + '" hoặc "' + KHONG + '").');
}
/** Kiểm tra & chuẩn hoá giá trị "Giới tính" (Nam/Nữ/Khác); để trống thì giữ trống, báo lỗi nếu không khớp. */
function checkGioiTinh_(v) {
  if (!v) return '';
  const s = normHeader_(v);
  const hit = LISTS.gioiTinh.find(function (x) { return normHeader_(x) === s; });
  if (!hit) throw new Error('Giới tính "' + v + '" không hợp lệ (chỉ nhận ' + LISTS.gioiTinh.map(function (x) { return '"' + x + '"'; }).join(', ') + ').');
  return hit;
}
function cleanNV_(o, user, maplMapObj, pbMapObj) {
  const r = {};
  NV_COLS.forEach(function (c) { r[c[0]] = o[c[0]] === undefined || o[c[0]] === null ? '' : o[c[0]]; });
  r.maNV = String(r.maNV).trim();
  r.hoTen = String(r.hoTen).trim();
  if (!r.maNV) throw new Error('Chưa nhập Mã NV.');
  if (!r.hoTen) throw new Error('Chưa nhập Họ và tên.');
  ['luongChinh', 'pcKN', 'pcCV', 'pcDH', 'pcKhac'].forEach(function (k) { r[k] = moneyNum_(r[k]); });
  r.luongDong = luongDong_(r);
  r.phongBan = checkPhongBan_(r.phongBan, pbMapObj);
  r.congDoan = checkCongDoan_(r.congDoan);
  r.gioiTinh = checkGioiTinh_(r.gioiTinh);
  r.emailQL = String(r.emailQL || '').toLowerCase().trim();
  if (user.role === ROLE.NHAP) r.emailQL = user.email;
  const mm = maplMapObj || maplMap_();
  if (r.maPL && !mm[r.maPL]) throw new Error('Mã phân loại "' + r.maPL + '" không tồn tại.');
  if (r.thangDung && r.ngayBHXH && normMonth_(r.thangDung) < r.ngayBHXH.slice(0, 7)) {
    throw new Error('Tháng dừng đóng không được trước tháng bắt đầu BHXH.');
  }
  return r;
}

function apiDeleteNV(ky, maNV) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  ky = normMonth_(ky);
  return withLock_(function () {
    let t = T.NV, rows;
    if (ky) { requireOpen_(ky); t = T.DLKY; rows = load_(T.DLKY).rows.filter(function (r) { return r.ky === ky && r.maNV === maNV; }); }
    else rows = load_(T.NV).rows.filter(function (r) { return r.maNV === maNV; });
    if (!rows.length) throw new Error('Không tìm thấy NV.');
    deleteRows_(t, rows.map(function (r) { return r._row; }));
    log_(user, 'Xóa NV', (ky ? 'Kỳ ' + monthDisp_(ky) : 'Hồ sơ gốc') + ' – ' + maNV);
    return true;
  });
}

// ---------------------------------------------------------------------
// API: TRUY THU / THOÁI THU
// ---------------------------------------------------------------------
function apiTruyThu(ky) {
  const user = getUser_();
  ky = normMonth_(ky);
  const k = getKy_(ky);
  const rows = load_(T.TT).rows.filter(function (r) { return r.ky === ky && canSee_(user, r); });
  const nvMap = {};
  load_(T.NV).rows.concat(load_(T.DLKY).rows.filter(function (r) { return r.ky === ky; })).forEach(function (r) {
    if (r.maNV && canSee_(user, r)) nvMap[r.maNV] = { maNV: r.maNV, hoTen: r.hoTen, maPL: r.maPL, congDoan: r.congDoan, luongDong: luongDong_(r), emailQL: r.emailQL };
  });
  return {
    ky: ky, trangThai: k.trangThai, editable: k.trangThai !== KY_CHOT && user.role !== ROLE.XEM,
    rows: rows, nvs: Object.keys(nvMap).map(function (x) { return nvMap[x]; })
  };
}

function apiSaveTruyThu(ky, o) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN, ROLE.NHAP]);
  ky = normMonth_(ky);
  return withLock_(function () {
    requireOpen_(ky);
    const tu = normMonth_(o.tuThang), den = normMonth_(o.denThang);
    if (!o.maNV) throw new Error('Chưa chọn nhân viên.');
    if (!tu || !den) throw new Error('Chưa nhập Từ tháng / Đến tháng.');
    if (tu > den) throw new Error('Từ tháng phải nhỏ hơn hoặc bằng Đến tháng.');
    if (den >= ky) throw new Error('Truy thu/thoái thu chỉ áp dụng cho các tháng trước kỳ ' + monthDisp_(ky) + '.');
    const nv = apiTruyThu(ky).nvs.find(function (x) { return x.maNV === o.maNV; });
    if (!nv) throw new Error('Không tìm thấy NV hoặc bạn không quản lý hồ sơ NV này.');
    const maplMap = maplMap_();
    const rec = {
      ky: ky, maNV: nv.maNV, hoTen: nv.hoTen, tuThang: tu, denThang: den,
      luongCu: moneyNum_(o.luongCu), luongMoi: moneyNum_(o.luongMoi),
      maPL: o.maPL || nv.maPL, congDoan: o.congDoan === CO ? CO : (o.congDoan === KHONG ? KHONG : nv.congDoan),
      ghiChu: o.ghiChu || '', emailQL: nv.emailQL
    };
    if (!maplMap[rec.maPL]) throw new Error('Mã phân loại không hợp lệ.');
    const ctx = ctxFactory_();
    const c = tinhTruyThu_(rec, ctx.fn, maplMap, congDoanCodes_(ctx.khoanRows), khoanTen_(ctx.khoanRows), load_(T.TLCD).rows);
    rec.soThang = c.soThang; rec.tienNLD = c.nld; rec.tienDN = c.dn;
    rec.bhxhNLD = c.bhxhNLD; rec.bhxhDN = c.bhxhDN;
    rec.dpcd = c.dpcd; rec.dpcdGiuLai = c.dpcdGiuLai; rec.dpcdNop = c.dpcdNop;
    rec.kpcd = c.kpcd; rec.kpcdGiuLai = c.kpcdGiuLai; rec.kpcdNop = c.kpcdNop;
    rec.chiTiet = c.chiTiet;
    if (o.id) {
      const ex = load_(T.TT).rows.find(function (r) { return r.id === o.id && r.ky === ky; });
      if (!ex || !canSee_(user, ex)) throw new Error('Không tìm thấy dòng truy thu.');
      rec.id = o.id;
      update_(T.TT, ex._row, rec);
    } else {
      rec.id = 'TT' + Date.now();
      rec.nguoiTao = user.email;
      append_(T.TT, [rec]);
    }
    log_(user, 'Lưu truy thu', monthDisp_(ky) + ' – ' + rec.maNV + ' ' + monthDisp_(tu) + '→' + monthDisp_(den));
    return rec;
  });
}

function apiDeleteTruyThu(ky, id) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN, ROLE.NHAP]);
  ky = normMonth_(ky);
  return withLock_(function () {
    requireOpen_(ky);
    const ex = load_(T.TT).rows.find(function (r) { return r.id === id && r.ky === ky; });
    if (!ex || !canSee_(user, ex)) throw new Error('Không tìm thấy dòng truy thu.');
    deleteRows_(T.TT, [ex._row]);
    log_(user, 'Xóa truy thu', monthDisp_(ky) + ' – ' + ex.maNV);
    return true;
  });
}

// ---------------------------------------------------------------------
// API: BÁO CÁO
// ---------------------------------------------------------------------
/** Tách phần "Thuộc quỹ Công đoàn" (DPCD_NLD, KPCD_DN…) ra khỏi tổng NLĐ/DN của một dòng kết quả tính */
function tachCongDoan_(r, cdSet, ten) {
  let cdNLD = 0, cdDN = 0;
  Object.keys(r.items).forEach(function (c) {
    if (!cdSet[c]) return;
    const v = r.items[c] || 0;
    if ((ten[c] || {}).doiTuong === DT_DN) cdDN += v; else cdNLD += v;
  });
  return { cdNLD: cdNLD, cdDN: cdDN };
}

/**
 * Tổng hợp một nhóm dòng kết quả tính + truy thu, tách theo đúng cấu trúc Báo cáo chi phí:
 * Tổng BHXH NLĐ/DN (không CĐ), Tổng nộp BHXH, DPCD_NLD, KPCD_DN, Tổng NLĐ/DN/cộng (đầy đủ, gồm CĐ),
 * và truy thu tách riêng theo BHXH / Công đoàn.
 */
function tomTatKy_(kqRows, ttRows, cdSet, ten) {
  const s = {
    soNV: 0, soDong: 0, quyLuong: 0, soCanhBao: 0, items: {},
    tongNLD: 0, tongDN: 0, tongCong: 0, cdNLD: 0, cdDN: 0,
    tongNLDChinh: 0, tongDNChinh: 0, tongNopBHXH: 0,
    ttBhxhNLD: 0, ttBhxhDN: 0, ttCdNLD: 0, ttCdDN: 0
  };
  kqRows.forEach(function (r) {
    s.soNV++;
    if (r.canhBao) s.soCanhBao++;
    if (r.dong !== CO) return;
    s.soDong++; s.quyLuong += r.luongDong; s.tongNLD += r.tongNLD; s.tongDN += r.tongDN; s.tongCong += r.tongCong;
    Object.keys(r.items).forEach(function (c) { s.items[c] = (s.items[c] || 0) + r.items[c]; });
    const cd = tachCongDoan_(r, cdSet, ten);
    s.cdNLD += cd.cdNLD; s.cdDN += cd.cdDN;
  });
  s.tongNLDChinh = s.tongNLD - s.cdNLD;
  s.tongDNChinh = s.tongDN - s.cdDN;
  s.tongNopBHXH = s.tongNLDChinh + s.tongDNChinh;
  ttRows.forEach(function (r) {
    s.ttBhxhNLD += (r.bhxhNLD || 0); s.ttBhxhDN += (r.bhxhDN || 0);
    s.ttCdNLD += (r.dpcd || 0); s.ttCdDN += (r.kpcd || 0);
  });
  s.ttBhxh = s.ttBhxhNLD + s.ttBhxhDN;
  s.ttCd = s.ttCdNLD + s.ttCdDN;
  s.tongNopCoQuanBHXH = s.tongNopBHXH + s.ttBhxh; // tổng nộp cơ quan BHXH, gồm cả truy thu
  s.tongCongDoan = s.cdNLD + s.cdDN + s.ttCd; // tổng quỹ Công đoàn, gồm cả truy thu
  return s;
}

/** Dữ liệu cho biểu đồ dashboard ở Tổng quan: biến động nhân sự/quỹ lương theo tháng, thâm niên, theo mã PL */
function apiDashboard(tuKy, denKy, phongBan) {
  const user = getUser_();
  const all = listKy_(); // mới nhất trước
  const minKy = all.length ? all[all.length - 1].ky : '', maxKy = all.length ? all[0].ky : '';
  tuKy = tuKy ? normMonth_(tuKy) : minKy;
  denKy = denKy ? normMonth_(denKy) : maxKy;
  if (tuKy && denKy && tuKy > denKy) { const x = tuKy; tuKy = denKy; denKy = x; }
  const kys = all.filter(function (k) { return k.ky >= tuKy && k.ky <= denKy; }).slice().reverse(); // tăng dần
  // Kỳ liền trước tuKy (nếu có), dùng làm mốc so sánh để tính tăng mới/nghỉ việc của tháng đầu tiên trong khoảng
  const idxTu = all.findIndex(function (k) { return k.ky === tuKy; });
  const baselineKy = idxTu >= 0 && idxTu + 1 < all.length ? all[idxTu + 1].ky : '';
  const neededKys = (baselineKy ? [baselineKy] : []).concat(kys.map(function (k) { return k.ky; }));
  const kqAll = loadKQAll_().rows.filter(function (r) { return neededKys.indexOf(r.ky) >= 0 && canSee_(user, r); });
  const kq = phongBan ? kqAll.filter(function (r) { return r.phongBan === phongBan; }) : kqAll;
  const setByKy = {};
  kq.forEach(function (r) { if (r.dong !== CO) return; (setByKy[r.ky] = setByKy[r.ky] || {})[r.maNV] = true; });
  const months = kys.map(function (k, i) {
    const rows = kq.filter(function (r) { return r.ky === k.ky && r.dong === CO; });
    const prevKy = i === 0 ? baselineKy : kys[i - 1].ky;
    const curSet = setByKy[k.ky] || {};
    const prevSet = prevKy ? (setByKy[prevKy] || {}) : null;
    let tangMoi = null, nghiViec = null;
    if (prevSet) {
      tangMoi = Object.keys(curSet).filter(function (m) { return !prevSet[m]; }).length;
      nghiViec = Object.keys(prevSet).filter(function (m) { return !curSet[m]; }).length;
    }
    return {
      ky: k.ky, soDong: rows.length, quyLuong: rows.reduce(function (s, r) { return s + r.luongDong; }, 0),
      tangMoi: tangMoi, nghiViec: nghiViec
    };
  });
  const lastKyRows = kq.filter(function (r) { return r.ky === denKy && r.dong === CO; });
  const dlky = load_(T.DLKY).rows.filter(function (r) { return r.ky === denKy; });
  const dlMap = {};
  dlky.forEach(function (r) { dlMap[r.maNV] = r; });
  const today = todayStr_();
  const buckets = [
    { label: '< 1 năm', min: 0, max: 1 }, { label: '1 - 3 năm', min: 1, max: 3 }, { label: '3 - 5 năm', min: 3, max: 5 },
    { label: '5 - 10 năm', min: 5, max: 10 }, { label: '> 10 năm', min: 10, max: 999 }, { label: 'Chưa rõ', min: -1, max: 0 }
  ];
  const bucketCounts = buckets.map(function (b) { return { label: b.label, count: 0 }; });
  lastKyRows.forEach(function (r) {
    const dl = dlMap[r.maNV];
    const start = dl && (dl.ngayVao || dl.ngayBHXH);
    if (!start) { bucketCounts[bucketCounts.length - 1].count++; return; }
    const years = (new Date(today) - new Date(start)) / (365.25 * 86400000);
    let idx = buckets.findIndex(function (b) { return b.min >= 0 && years >= b.min && years < b.max; });
    if (idx < 0) idx = buckets.length - 2; // > 10 năm mặc định nếu vượt hết mốc
    bucketCounts[idx].count++;
  });
  const byMaPLMap = {};
  lastKyRows.forEach(function (r) { const k = r.maPL || '(Chưa có)'; byMaPLMap[k] = (byMaPLMap[k] || 0) + 1; });
  const byMaPL = Object.keys(byMaPLMap).map(function (k) { return { maPL: k, count: byMaPLMap[k] }; });
  return {
    tuKy: tuKy, denKy: denKy, minKy: minKy, maxKy: maxKy, months: months,
    seniority: bucketCounts, byMaPL: byMaPL, tongNVCuoiKy: lastKyRows.length
  };
}

function apiBaoCaoChiTiet(ky) {
  const user = getUser_();
  ky = normMonth_(ky);
  const k = getKy_(ky);
  const kq = loadKQAll_();
  const rows = kq.rows.filter(function (r) { return r.ky === ky && canSee_(user, r); });
  const khoanRows = load_(T.KHOAN).rows;
  const ten = khoanTen_(khoanRows);
  const cdSet = congDoanCodes_(khoanRows);
  const tong = {};
  rows.forEach(function (r) { Object.keys(r.items).forEach(function (c) { tong[c] = (tong[c] || 0) + Math.abs(r.items[c]); }); });
  const allCodes = kq.codes.filter(function (c) { return tong[c]; }).map(function (c) {
    return ten[c] || { ma: c, ten: c, doiTuong: c.slice(-2) === 'DN' ? DT_DN : DT_NLD };
  });
  // Tách riêng các khoản "Thuộc quỹ Công đoàn" (đoàn phí NLĐ, kinh phí công đoàn DN) ra sau cùng
  const codes = allCodes.filter(function (c) { return !cdSet[c.ma]; });
  const codesCD = allCodes.filter(function (c) { return cdSet[c.ma]; });
  codes.sort(function (a, b) { return (a.doiTuong === DT_DN) - (b.doiTuong === DT_DN); });
  codesCD.sort(function (a, b) { return (a.doiTuong === DT_DN) - (b.doiTuong === DT_DN); });
  rows.forEach(function (r) {
    let cdNLD = 0, cdDN = 0;
    codesCD.forEach(function (c) {
      const v = r.items[c.ma] || 0;
      if (c.doiTuong === DT_DN) cdDN += v; else cdNLD += v;
    });
    r.cdNLD = cdNLD; r.cdDN = cdDN;
    r.tongNLDChinh = r.tongNLD - cdNLD; // Tổng BHXH NLĐ không gồm đoàn phí công đoàn
    r.tongDNChinh = r.tongDN - cdDN; // Tổng BHXH DN không gồm kinh phí công đoàn
    r.tongNopBHXH = r.tongNLDChinh + r.tongDNChinh; // Tổng nộp BHXH (NLĐ + DN, không gồm Công đoàn)
  });
  const tt = load_(T.TT).rows.filter(function (r) { return r.ky === ky && canSee_(user, r); });
  return { info: getInfo_(), ky: ky, kyInfo: k, codes: codes, codesCD: codesCD, rows: rows, truyThu: tt };
}

function apiBienDong(ky) {
  const user = getUser_();
  ky = normMonth_(ky);
  const k = getKy_(ky);
  const prev = listKy_().map(function (x) { return x.ky; }).filter(function (x) { return x < ky; })[0] || '';
  const kq = loadKQAll_().rows.filter(function (r) { return canSee_(user, r); });
  const cur = kq.filter(function (r) { return r.ky === ky; });
  if (!cur.length) throw new Error('Kỳ ' + monthDisp_(ky) + ' chưa được tính. Hãy bấm "Tính" ở màn hình Kỳ BHXH.');
  const pre = prev ? kq.filter(function (r) { return r.ky === prev; }) : [];
  const dl = {};
  load_(T.DLKY).rows.forEach(function (r) { if (r.ky === ky || r.ky === prev) dl[r.ky + '|' + r.maNV] = r; });
  const P = {}, C = {};
  pre.forEach(function (r) { P[r.maNV] = r; });
  cur.forEach(function (r) { C[r.maNV] = r; });
  const out = [];
  const add = function (loai, c, p, ghiChu) {
    const x = c || p;
    out.push({
      loai: loai, maNV: x.maNV, hoTen: x.hoTen, maBHXH: x.maBHXH, chucDanh: x.chucDanh, phongBan: x.phongBan,
      luongCu: p ? p.luongDong : '', luongMoi: c && c.dong === CO ? c.luongDong : '',
      maPLCu: p ? p.maPL : '', maPLMoi: c ? c.maPL : '', tuThang: ky, denThang: '', ghiChu: ghiChu || ''
    });
  };
  const lyDoGiam = function (maNV, fallback) {
    const d = dl[ky + '|' + maNV] || dl[prev + '|' + maNV];
    const a = [];
    if (d && d.ngayNghi) a.push('Nghỉ việc ngày ' + dateDisp_(d.ngayNghi));
    if (d && d.thangDung) a.push('Dừng đóng từ ' + monthDisp_(d.thangDung));
    return a.join('; ') || fallback || '';
  };
  if (prev) {
    cur.forEach(function (c) {
      const p = P[c.maNV];
      const cd = c.dong === CO, pd = !!p && p.dong === CO;
      if (cd && !pd) add('Tăng mới', c, null, p ? 'Đóng lại' : '');
      else if (!cd && pd) add('Giảm', c, p, lyDoGiam(c.maNV, c.canhBao));
      else if (cd && pd) {
        if (c.luongDong !== p.luongDong) add(c.luongDong > p.luongDong ? 'Điều chỉnh tăng lương' : 'Điều chỉnh giảm lương', c, p);
        if (c.maPL !== p.maPL) add('Đổi mã phân loại', c, p);
      }
    });
    pre.forEach(function (p) { if (!C[p.maNV] && p.dong === CO) add('Giảm', null, p, lyDoGiam(p.maNV, 'Không có trong kỳ')); });
  }
  load_(T.TT).rows.filter(function (r) { return r.ky === ky && canSee_(user, r); }).forEach(function (t) {
    out.push({
      loai: (t.tienNLD + t.tienDN) >= 0 ? 'Truy thu' : 'Thoái thu', maNV: t.maNV, hoTen: t.hoTen,
      maBHXH: (C[t.maNV] || P[t.maNV] || {}).maBHXH || '', chucDanh: (C[t.maNV] || {}).chucDanh || '',
      phongBan: (C[t.maNV] || {}).phongBan || '', luongCu: t.luongCu, luongMoi: t.luongMoi,
      maPLCu: t.maPL, maPLMoi: t.maPL, tuThang: t.tuThang, denThang: t.denThang,
      ghiChu: [t.ghiChu, 'NLĐ: ' + fmtNum_(t.tienNLD) + ', DN: ' + fmtNum_(t.tienDN)].filter(String).join(' – ')
    });
  });
  return { info: getInfo_(), ky: ky, prev: prev, kyInfo: k, rows: out };
}

function apiTongHop(tuKy, denKy) {
  const user = getUser_();
  const all = listKy_(); // mới nhất trước
  const minKy = all.length ? all[all.length - 1].ky : '', maxKy = all.length ? all[0].ky : '';
  tuKy = tuKy ? normMonth_(tuKy) : minKy;
  denKy = denKy ? normMonth_(denKy) : maxKy;
  if (tuKy && denKy && tuKy > denKy) { const x = tuKy; tuKy = denKy; denKy = x; }
  const kys = all.filter(function (k) { return k.ky >= tuKy && k.ky <= denKy; }).slice().reverse(); // tăng dần
  const kq = loadKQAll_();
  const rows = kq.rows.filter(function (r) { return r.ky >= tuKy && r.ky <= denKy && canSee_(user, r); });
  const tt = load_(T.TT).rows.filter(function (r) { return r.ky >= tuKy && r.ky <= denKy && canSee_(user, r); });
  const khoanRows = load_(T.KHOAN).rows;
  const cdSet = congDoanCodes_(khoanRows);
  const ten = khoanTen_(khoanRows);
  const months = kys.map(function (k) {
    const s = tomTatKy_(rows.filter(function (r) { return r.ky === k.ky; }), tt.filter(function (r) { return r.ky === k.ky; }), cdSet, ten);
    s.ky = k.ky; s.trangThai = k.trangThai; s.daTinh = !!k.ngayTinh;
    return s;
  });
  const codes = kq.codes.filter(function (c) { return months.some(function (m) { return m.items[c]; }); }).map(function (c) {
    const o = ten[c] || { ma: c, ten: c, doiTuong: '' };
    return { ma: o.ma, ten: o.ten, doiTuong: o.doiTuong };
  });
  codes.sort(function (a, b) { return (a.doiTuong === DT_DN) - (b.doiTuong === DT_DN); });
  // Tổng theo cả khoảng thời gian đã chọn
  const total = tomTatKy_(rows, tt, cdSet, ten);
  delete total.items;
  // Tổng hợp theo phòng ban (cả khoảng thời gian, không tách theo tháng)
  const pbOfNV = {};
  rows.forEach(function (r) { if (r.phongBan) pbOfNV[r.maNV] = r.phongBan; });
  const pbMap = {};
  const ensurePB = function (pb) { if (!pbMap[pb]) pbMap[pb] = { rows: [], tt: [] }; return pbMap[pb]; };
  rows.forEach(function (r) { ensurePB(r.phongBan || '(Chưa có phòng ban)').rows.push(r); });
  tt.forEach(function (t) { ensurePB(pbOfNV[t.maNV] || '(Chưa có phòng ban)').tt.push(t); });
  const phongBan = Object.keys(pbMap).sort(function (a, b) { return a.localeCompare(b, 'vi'); }).map(function (pb) {
    const s = tomTatKy_(pbMap[pb].rows, pbMap[pb].tt, cdSet, ten);
    delete s.items;
    s.phongBan = pb;
    return s;
  });
  return { info: getInfo_(), tuKy: tuKy, denKy: denKy, minKy: minKy, maxKy: maxKy, months: months, codes: codes, total: total, phongBan: phongBan };
}

/** Các mã khoản trích được đánh dấu "Thuộc quỹ Công đoàn" (ở bất kỳ phiên bản nào) */
function congDoanCodes_(khoanRows) {
  const set = {};
  khoanRows.forEach(function (r) { if (r.thuocCD === CO) set[r.ma] = true; });
  return set;
}

/** Bảng phân tách quỹ Công đoàn chi tiết theo từng nhân viên/phòng ban trong một kỳ */
function apiCongDoanChiTiet(ky) {
  const user = getUser_();
  ky = normMonth_(ky);
  const k = getKy_(ky);
  const khoanRows = load_(T.KHOAN).rows;
  const cdCodes = congDoanCodes_(khoanRows);
  const ten = khoanTen_(khoanRows);
  const tlRows = load_(T.TLCD).rows;
  const tl = tyLeGiuLaiHieuLuc_(tlRows, ky);
  const kq = loadKQAll_().rows.filter(function (r) { return r.ky === ky && canSee_(user, r); });
  const rows = kq.filter(function (r) { return r.dong === CO; }).map(function (r) {
    let cdNLD = 0, cdDN = 0;
    Object.keys(r.items).forEach(function (c) {
      if (!cdCodes[c]) return;
      if ((ten[c] || {}).doiTuong === DT_DN) cdDN += r.items[c]; else cdNLD += r.items[c];
    });
    // Tính phần nộp Công đoàn Việt Nam trước và làm tròn, phần giữ lại cơ sở = phần còn lại (không làm tròn riêng)
    const nopNLD = round0_(cdNLD * (100 - tl.nld) / 100);
    const nopDN = round0_(cdDN * (100 - tl.dn) / 100);
    return {
      maNV: r.maNV, hoTen: r.hoTen, maBHXH: r.maBHXH, phongBan: r.phongBan, chucDanh: r.chucDanh, maPL: r.maPL,
      luongDong: r.luongDong, cdNLD: cdNLD, giuLaiNLD: cdNLD - nopNLD, nopNLD: nopNLD,
      cdDN: cdDN, giuLaiDN: cdDN - nopDN, nopDN: nopDN
    };
  });
  const tt = load_(T.TT).rows.filter(function (r) { return r.ky === ky && canSee_(user, r) && (r.dpcd || r.kpcd); });
  return {
    info: getInfo_(), ky: ky, kyInfo: k, tyLeNLD: tl.nld, tyLeDN: tl.dn,
    coCauHinh: Object.keys(cdCodes).length > 0, coTyLe: tlRows.length > 0, rows: rows, truyThu: tt
  };
}

function todayStr_() { return Utilities.formatDate(new Date(), tz_(), 'yyyy-MM-dd'); }

/** Số năm/tháng/ngày giữa 2 ngày ISO (yyyy-MM-dd); null nếu thiếu dữ liệu hoặc endStr < startStr */
function tinhThamNien_(startStr, endStr) {
  if (!startStr) return null;
  const s = new Date(startStr + 'T00:00:00');
  const e = new Date((endStr || todayStr_()) + 'T00:00:00');
  if (isNaN(s.getTime()) || isNaN(e.getTime()) || e < s) return null;
  let years = e.getFullYear() - s.getFullYear();
  let months = e.getMonth() - s.getMonth();
  let days = e.getDate() - s.getDate();
  if (days < 0) { months--; days += new Date(e.getFullYear(), e.getMonth(), 0).getDate(); }
  if (months < 0) { years--; months += 12; }
  return { years: years, months: months, days: days };
}
function thamNienStr_(t) { return t ? (t.years + ' năm ' + t.months + ' tháng ' + t.days + ' ngày') : ''; }

/** Tổng hợp theo nhân sự: lịch sử từng kỳ đóng trong khoảng thời gian + thâm niên tính đến cuối khoảng (hoặc hôm nay) */
function apiLichSuNhanSu(tuKy, denKy) {
  const user = getUser_();
  const all = listKy_(); // mới nhất trước
  const minKy = all.length ? all[all.length - 1].ky : '', maxKy = all.length ? all[0].ky : '';
  tuKy = tuKy ? normMonth_(tuKy) : minKy;
  denKy = denKy ? normMonth_(denKy) : maxKy;
  if (tuKy && denKy && tuKy > denKy) { const x = tuKy; tuKy = denKy; denKy = x; }
  const kq = loadKQAll_().rows.filter(function (r) { return r.ky >= tuKy && r.ky <= denKy && canSee_(user, r); });
  const dlky = load_(T.DLKY).rows.filter(function (r) { return r.ky >= tuKy && r.ky <= denKy; });
  const dlMap = {};
  dlky.forEach(function (r) { dlMap[r.ky + '|' + r.maNV] = r; });
  const byNV = {};
  kq.forEach(function (r) {
    if (!byNV[r.maNV]) byNV[r.maNV] = { maNV: r.maNV, periods: [], _lastKy: '' };
    const nv = byNV[r.maNV];
    const dl = dlMap[r.ky + '|' + r.maNV] || {};
    nv.periods.push({
      ky: r.ky, maPL: r.maPL, luongDong: r.luongDong, dong: r.dong, phongBan: r.phongBan, chucDanh: r.chucDanh,
      tongNLD: r.tongNLD, tongDN: r.tongDN, tongCong: r.tongCong, canhBao: r.canhBao
    });
    if (r.ky >= nv._lastKy) {
      nv._lastKy = r.ky; nv.hoTen = r.hoTen; nv.maBHXH = dl.maBHXH || r.maBHXH || '';
      nv.phongBanHienTai = r.phongBan; nv.chucDanhHienTai = r.chucDanh;
      nv.ngayVao = dl.ngayVao || ''; nv.ngayBHXH = dl.ngayBHXH || '';
      nv.ngayNghi = dl.ngayNghi || ''; nv.thangDung = dl.thangDung || '';
    }
  });
  const today = todayStr_();
  const kyHomNay = normMonth_(today.slice(0, 7));
  const list = Object.keys(byNV).map(function (k) {
    const nv = byNV[k];
    delete nv._lastKy;
    nv.periods.sort(function (a, b) { return a.ky < b.ky ? -1 : 1; });
    const start = nv.ngayVao || nv.ngayBHXH;
    const dangLam = !nv.thangDung || nv.thangDung > kyHomNay;
    const end = dangLam ? today : nv.thangDung + '-01';
    nv.dangLam = dangLam;
    nv.thamNien = tinhThamNien_(start, end);
    nv.thamNienNam = nv.thamNien ? Math.round((nv.thamNien.years + nv.thamNien.months / 12 + nv.thamNien.days / 365) * 100) / 100 : null;
    return nv;
  }).sort(function (a, b) { return (a.phongBanHienTai + a.maNV) < (b.phongBanHienTai + b.maNV) ? -1 : 1; });
  return { info: getInfo_(), tuKy: tuKy, denKy: denKy, minKy: minKy, maxKy: maxKy, rows: list };
}

// ---------------------------------------------------------------------
// API: XUẤT EXCEL / PDF
// ---------------------------------------------------------------------
function apiXuat(loai, thamSo, format) {
  const doc = buildDoc_(loai, thamSo);
  return makeFile_(doc, format === 'pdf' ? 'pdf' : 'xlsx');
}

function buildDoc_(loai, p) {
  if (loai === 'chitiet') {
    const d = apiBaoCaoChiTiet(p);
    const codesNLD = d.codes.filter(function (c) { return c.doiTuong !== DT_DN; });
    const codesDN = d.codes.filter(function (c) { return c.doiTuong === DT_DN; });
    const header = ['STT', 'Mã NV', 'Họ và tên', 'Chức danh', 'Đơn vị_Phòng ban', 'Mã PL', 'Lương đóng BHXH']
      .concat(codesNLD.map(function (c) { return c.ten + ' (' + c.ma + ')'; }))
      .concat(['Tổng BHXH NLĐ (không gồm Đoàn phí CĐ)'])
      .concat(codesDN.map(function (c) { return c.ten + ' (' + c.ma + ')'; }))
      .concat(['Tổng BHXH DN (không gồm KPCĐ)', 'Tổng nộp cơ quan BHXH (NLĐ + DN)'])
      .concat(d.codesCD.map(function (c) { return c.ten + ' (' + c.ma + ')'; }))
      .concat(['Ghi chú']);
    const dong = d.rows.filter(function (r) { return r.dong === CO; })
      .sort(function (a, b) { return (a.phongBan + a.maNV) < (b.phongBan + b.maNV) ? -1 : 1; });
    const rows = dong.map(function (r, i) {
      return [i + 1, r.maNV, r.hoTen, r.chucDanh, r.phongBan, r.maPL, r.luongDong]
        .concat(codesNLD.map(function (c) { return r.items[c.ma] || 0; }))
        .concat([r.tongNLDChinh])
        .concat(codesDN.map(function (c) { return r.items[c.ma] || 0; }))
        .concat([r.tongDNChinh, r.tongNopBHXH])
        .concat(d.codesCD.map(function (c) { return r.items[c.ma] || 0; }))
        .concat([r.canhBao]);
    });
    const sum = function (col) { return rows.reduce(function (s, r) { return s + (Number(r[col]) || 0); }, 0); };
    const total = ['', '', 'TỔNG CỘNG', '', '', '', sum(6)];
    for (let c = 7; c < header.length - 1; c++) total.push(sum(c));
    total.push('');
    const numCols = [];
    for (let c = 6; c < header.length - 1; c++) numCols.push(c);
    const sections = [{ title: 'Danh sách NV đóng BHXH (' + dong.length + ' người) – dùng để nộp cơ quan BHXH', header: header, rows: rows, total: total, numCols: numCols }];
    if (d.truyThu.length) {
      const h2 = ['STT', 'Mã NV', 'Họ và tên', 'Từ tháng', 'Đến tháng', 'Số tháng', 'Lương cũ', 'Lương mới',
        'Truy thu BHXH NLĐ', 'Truy thu BHXH DN', 'Chi tiết', 'Ghi chú'];
      const r2 = d.truyThu.map(function (t, i) {
        return [i + 1, t.maNV, t.hoTen, monthDisp_(t.tuThang), monthDisp_(t.denThang), t.soThang, t.luongCu, t.luongMoi,
          t.bhxhNLD, t.bhxhDN, t.chiTiet, t.ghiChu];
      });
      const s2 = function (i) { return r2.reduce(function (s, r) { return s + r[i]; }, 0); };
      const tot2 = ['', '', 'TỔNG', '', '', '', '', '', s2(8), s2(9), '', ''];
      sections.push({
        title: 'Truy thu / Thoái thu BHXH (nộp cơ quan BHXH – không gồm Công đoàn, xem ở Báo cáo Công đoàn)',
        header: h2, rows: r2, total: tot2, numCols: [6, 7, 8, 9]
      });
    }
    return { info: d.info, title: 'BẢNG TÍNH NỘP BHXH – KỲ ' + monthDisp_(d.ky), fileName: 'BHXH_ChiTiet_' + d.ky, sections: sections };
  }
  if (loai === 'chiphi') {
    const d = apiBaoCaoChiTiet(p);
    const header = ['STT', 'Mã NV', 'Họ và tên', 'Chức danh', 'Đơn vị_Phòng ban', 'Mã PL', 'Lương đóng BHXH',
      'Tổng BHXH NLĐ', 'Tổng BHXH DN', 'Tổng nộp BHXH', 'Đoàn phí CĐ (NLĐ)', 'Kinh phí CĐ (DN)', 'Tổng NLĐ', 'Tổng DN', 'Tổng cộng'];
    const dong = d.rows.filter(function (r) { return r.dong === CO; })
      .sort(function (a, b) { return (a.phongBan + a.maNV) < (b.phongBan + b.maNV) ? -1 : 1; });
    const rows = dong.map(function (r, i) {
      return [i + 1, r.maNV, r.hoTen, r.chucDanh, r.phongBan, r.maPL, r.luongDong,
        r.tongNLDChinh, r.tongDNChinh, r.tongNopBHXH, r.cdNLD, r.cdDN, r.tongNLD, r.tongDN, r.tongCong];
    });
    const sum = function (col) { return rows.reduce(function (s, r) { return s + (Number(r[col]) || 0); }, 0); };
    const total = ['', '', 'TỔNG CỘNG', '', '', '', sum(6), sum(7), sum(8), sum(9), sum(10), sum(11), sum(12), sum(13), sum(14)];
    const totals = [total];
    if (d.truyThu.length) {
      const ttNLD = d.truyThu.reduce(function (s, t) { return s + (t.bhxhNLD || 0); }, 0);
      const ttDN = d.truyThu.reduce(function (s, t) { return s + (t.bhxhDN || 0); }, 0);
      const ttCdNLD = d.truyThu.reduce(function (s, t) { return s + (t.dpcd || 0); }, 0);
      const ttCdDN = d.truyThu.reduce(function (s, t) { return s + (t.kpcd || 0); }, 0);
      const ttTongNLD = d.truyThu.reduce(function (s, t) { return s + (t.tienNLD || 0); }, 0);
      const ttTongDN = d.truyThu.reduce(function (s, t) { return s + (t.tienDN || 0); }, 0);
      totals.push(['', '', 'Truy thu / Thoái thu', '', '', '', '', ttNLD, ttDN, ttNLD + ttDN, ttCdNLD, ttCdDN, ttTongNLD, ttTongDN, ttTongNLD + ttTongDN]);
      totals.push(['', '', 'TỔNG CỘNG SAU TRUY THU', '', '', '', sum(6), sum(7) + ttNLD, sum(8) + ttDN, sum(9) + ttNLD + ttDN,
        sum(10) + ttCdNLD, sum(11) + ttCdDN, sum(12) + ttTongNLD, sum(13) + ttTongDN, sum(14) + ttTongNLD + ttTongDN]);
    }
    const sections = [{ title: 'Chi phí theo nhân viên (' + dong.length + ' người)', header: header, rows: rows, total: totals, numCols: [6, 7, 8, 9, 10, 11, 12, 13, 14] }];
    if (d.truyThu.length) {
      const h2 = ['STT', 'Mã NV', 'Họ và tên', 'Từ tháng', 'Đến tháng', 'Số tháng', 'Lương cũ', 'Lương mới',
        'BHXH NLĐ', 'BHXH DN', 'DPCD giữ lại', 'DPCD nộp CĐVN', 'KPCD giữ lại', 'KPCD nộp CĐVN', 'Tổng NLĐ', 'Tổng DN', 'Tổng cộng', 'Chi tiết'];
      const r2 = d.truyThu.map(function (t, i) {
        return [i + 1, t.maNV, t.hoTen, monthDisp_(t.tuThang), monthDisp_(t.denThang), t.soThang, t.luongCu, t.luongMoi,
          t.bhxhNLD, t.bhxhDN, t.dpcdGiuLai, t.dpcdNop, t.kpcdGiuLai, t.kpcdNop, t.tienNLD, t.tienDN, t.tienNLD + t.tienDN, t.chiTiet];
      });
      const s2 = function (i) { return r2.reduce(function (s, r) { return s + r[i]; }, 0); };
      const tot2 = ['', '', 'TỔNG', '', '', '', '', '', s2(8), s2(9), s2(10), s2(11), s2(12), s2(13), s2(14), s2(15), s2(16), ''];
      sections.push({
        title: 'Truy thu / Thoái thu (đầy đủ, gồm cả Công đoàn)',
        header: h2, rows: r2, total: tot2, numCols: [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
      });
    }
    return { info: d.info, title: 'BÁO CÁO CHI PHÍ BHXH – KỲ ' + monthDisp_(d.ky), fileName: 'BHXH_ChiPhi_' + d.ky, sections: sections };
  }
  if (loai === 'biendong') {
    const d = apiBienDong(p);
    const header = ['STT', 'Loại biến động', 'Mã NV', 'Họ và tên', 'Mã số BHXH', 'Chức danh', 'Đơn vị_Phòng ban',
      'Lương cũ', 'Lương mới', 'Mã PL cũ', 'Mã PL mới', 'Từ tháng', 'Đến tháng', 'Ghi chú'];
    const rows = d.rows.map(function (r, i) {
      return [i + 1, r.loai, r.maNV, r.hoTen, r.maBHXH, r.chucDanh, r.phongBan, r.luongCu, r.luongMoi,
        r.maPLCu, r.maPLMoi, monthDisp_(r.tuThang), monthDisp_(r.denThang), r.ghiChu];
    });
    return {
      info: d.info, title: 'BÁO CÁO BIẾN ĐỘNG TĂNG/GIẢM – KỲ ' + monthDisp_(d.ky),
      subtitle: d.prev ? 'So với kỳ ' + monthDisp_(d.prev) : 'Không có kỳ trước để so sánh',
      fileName: 'BHXH_BienDong_' + d.ky, sections: [{ title: '', header: header, rows: rows, numCols: [7, 8] }]
    };
  }
  if (loai === 'tonghop') {
    const pp = String(p || '').split('|');
    const d = apiTongHop(pp[0], pp[1]);
    const h1 = ['Kỳ', 'Trạng thái', 'NV đóng', 'Quỹ lương đóng', 'Tổng BHXH NLĐ', 'Truy thu BHXH NLĐ', 'Tổng BHXH DN', 'Truy thu BHXH DN', 'Tổng nộp BHXH',
      'DPCD_NLD', 'Truy thu DPCD_NLD', 'Tổng DPCD_NLD', 'KPCD_DN', 'Truy thu KPCD_DN', 'Tổng KPCD_DN', 'Tổng NLĐ', 'Tổng DN', 'Tổng cộng'];
    const r1 = d.months.map(function (m) {
      return [monthDisp_(m.ky), m.trangThai, m.soDong, m.quyLuong, m.tongNLDChinh, m.ttBhxhNLD, m.tongDNChinh, m.ttBhxhDN, m.tongNopCoQuanBHXH,
        m.cdNLD, m.ttCdNLD, m.cdNLD + m.ttCdNLD, m.cdDN, m.ttCdDN, m.cdDN + m.ttCdDN, m.tongNLD, m.tongDN, m.tongCong];
    });
    const s = function (i) { return r1.reduce(function (a, r) { return a + r[i]; }, 0); };
    const t1 = ['CẢ KỲ', '', s(2), s(3), s(4), s(5), s(6), s(7), s(8), s(9), s(10), s(11), s(12), s(13), s(14), s(15), s(16), s(17)];
    const h3 = ['Phòng ban', 'Quỹ lương đóng', 'Tổng BHXH NLĐ', 'Truy thu BHXH NLĐ', 'Tổng BHXH DN', 'Truy thu BHXH DN', 'Tổng nộp BHXH',
      'DPCD_NLD', 'Truy thu DPCD_NLD', 'Tổng DPCD_NLD', 'KPCD_DN', 'Truy thu KPCD_DN', 'Tổng KPCD_DN', 'Tổng NLĐ', 'Tổng DN', 'Tổng cộng'];
    const r3 = d.phongBan.map(function (b) {
      return [b.phongBan, b.quyLuong, b.tongNLDChinh, b.ttBhxhNLD, b.tongDNChinh, b.ttBhxhDN, b.tongNopCoQuanBHXH,
        b.cdNLD, b.ttCdNLD, b.cdNLD + b.ttCdNLD, b.cdDN, b.ttCdDN, b.cdDN + b.ttCdDN, b.tongNLD, b.tongDN, b.tongCong];
    });
    const s3 = function (i) { return r3.reduce(function (a, r) { return a + r[i]; }, 0); };
    const t3 = ['TỔNG CỘNG', s3(1), s3(2), s3(3), s3(4), s3(5), s3(6), s3(7), s3(8), s3(9), s3(10), s3(11), s3(12), s3(13), s3(14), s3(15)];
    const h2 = ['Mã khoản', 'Tên khoản', 'Đối tượng'].concat(d.months.map(function (m) { return monthDisp_(m.ky); })).concat(['Cả kỳ']);
    const r2 = d.codes.map(function (c) {
      const vals = d.months.map(function (m) { return m.items[c.ma] || 0; });
      return [c.ma, c.ten, c.doiTuong].concat(vals).concat([vals.reduce(function (a, b) { return a + b; }, 0)]);
    });
    const nc2 = [];
    for (let i = 3; i < h2.length; i++) nc2.push(i);
    return {
      info: d.info, title: 'TỔNG HỢP BHXH – TỪ ' + monthDisp_(d.tuKy) + ' ĐẾN ' + monthDisp_(d.denKy), fileName: 'BHXH_TongHop_' + d.tuKy + '_' + d.denKy,
      sections: [
        { title: 'Tổng hợp theo tháng', header: h1, rows: r1, total: t1, numCols: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17] },
        { title: 'Tổng hợp theo phòng ban (cả khoảng thời gian)', header: h3, rows: r3, total: t3, numCols: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15] },
        { title: 'Chi tiết theo khoản trích (không gồm truy thu)', header: h2, rows: r2, numCols: nc2 }
      ]
    };
  }
  if (loai === 'congdoan') {
    const d = apiCongDoanChiTiet(p);
    const header = ['STT', 'Mã NV', 'Họ và tên', 'Mã số BHXH', 'Đơn vị_Phòng ban', 'Mã PL', 'Lương đóng BHXH',
      'Đoàn phí công đoàn (NLĐ)', 'Tỉ lệ giữ lại NLĐ (%)', 'Giữ lại cơ sở (NLĐ)', 'Nộp Công đoàn VN (NLĐ)',
      'Kinh phí công đoàn (DN)', 'Tỉ lệ giữ lại DN (%)', 'Giữ lại cơ sở (DN)', 'Nộp Công đoàn VN (DN)'];
    const rows = d.rows.slice().sort(function (a, b) { return (a.phongBan + a.maNV) < (b.phongBan + b.maNV) ? -1 : 1; })
      .map(function (r, i) {
        return [i + 1, r.maNV, r.hoTen, r.maBHXH, r.phongBan, r.maPL, r.luongDong,
          r.cdNLD, d.tyLeNLD, r.giuLaiNLD, r.nopNLD, r.cdDN, d.tyLeDN, r.giuLaiDN, r.nopDN];
      });
    const s = function (i) { return rows.reduce(function (a, r) { return a + r[i]; }, 0); };
    const total = ['', '', 'TỔNG CỘNG', '', '', '', s(6), s(7), '', s(9), s(10), s(11), '', s(13), s(14)];
    const totals = [total];
    if (d.truyThu.length) {
      const ttCdNLD = d.truyThu.reduce(function (a, t) { return a + (t.dpcd || 0); }, 0);
      const ttGiuLaiNLD = d.truyThu.reduce(function (a, t) { return a + (t.dpcdGiuLai || 0); }, 0);
      const ttNopNLD = d.truyThu.reduce(function (a, t) { return a + (t.dpcdNop || 0); }, 0);
      const ttCdDN = d.truyThu.reduce(function (a, t) { return a + (t.kpcd || 0); }, 0);
      const ttGiuLaiDN = d.truyThu.reduce(function (a, t) { return a + (t.kpcdGiuLai || 0); }, 0);
      const ttNopDN = d.truyThu.reduce(function (a, t) { return a + (t.kpcdNop || 0); }, 0);
      totals.push(['', '', 'Truy thu / Thoái thu', '', '', '', '', ttCdNLD, '', ttGiuLaiNLD, ttNopNLD, ttCdDN, '', ttGiuLaiDN, ttNopDN]);
      totals.push(['', '', 'TỔNG CỘNG SAU TRUY THU', '', '', '', s(6), s(7) + ttCdNLD, '', s(9) + ttGiuLaiNLD, s(10) + ttNopNLD,
        s(11) + ttCdDN, '', s(13) + ttGiuLaiDN, s(14) + ttNopDN]);
    }
    const sections = [{ title: '', header: header, rows: rows, total: totals, numCols: [6, 7, 9, 10, 11, 13, 14] }];
    if (d.truyThu.length) {
      const h2 = ['STT', 'Mã NV', 'Họ và tên', 'Từ tháng', 'Đến tháng', 'Số tháng', 'Lương cũ', 'Lương mới',
        'Đoàn phí – giữ lại (NLĐ)', 'Đoàn phí – nộp CĐVN (NLĐ)', 'Kinh phí – giữ lại (DN)', 'Kinh phí – nộp CĐVN (DN)', 'Chi tiết'];
      const r2 = d.truyThu.map(function (t, i) {
        return [i + 1, t.maNV, t.hoTen, monthDisp_(t.tuThang), monthDisp_(t.denThang), t.soThang, t.luongCu, t.luongMoi,
          t.dpcdGiuLai, t.dpcdNop, t.kpcdGiuLai, t.kpcdNop, t.chiTiet];
      });
      const s2 = function (i) { return r2.reduce(function (s, r) { return s + r[i]; }, 0); };
      const tot2 = ['', '', 'TỔNG', '', '', '', '', '', s2(8), s2(9), s2(10), s2(11), ''];
      sections.push({ title: 'Truy thu / Thoái thu Công đoàn', header: h2, rows: r2, total: tot2, numCols: [6, 7, 8, 9, 10, 11] });
    }
    return {
      info: d.info, title: 'BẢNG PHÂN TÁCH QUỸ CÔNG ĐOÀN – KỲ ' + monthDisp_(d.ky), fileName: 'CongDoan_' + d.ky,
      sections: sections
    };
  }
  if (loai === 'nhansu') {
    const pp = String(p || '').split('|');
    const d = apiLichSuNhanSu(pp[0], pp[1]);
    const header = ['STT', 'Mã NV', 'Họ và tên', 'Mã số BHXH', 'Ngày vào làm', 'Ngày bắt đầu BHXH',
      'Thâm niên (đến hôm nay, hoặc đến ngày dừng đóng nếu đã nghỉ)', 'Thâm niên (năm, số thập phân)',
      'Kỳ', 'Chức danh', 'Đơn vị_Phòng ban', 'Mã PL', 'Đóng trong kỳ', 'Lương đóng BHXH', 'Tổng NLĐ', 'Tổng DN', 'Tổng cộng', 'Cảnh báo'];
    const rows = [];
    d.rows.forEach(function (nv) {
      nv.periods.forEach(function (per, i) {
        rows.push([rows.length + 1, nv.maNV, nv.hoTen, nv.maBHXH, dateDisp_(nv.ngayVao), dateDisp_(nv.ngayBHXH),
          i === 0 ? thamNienStr_(nv.thamNien) : '', i === 0 ? nv.thamNienNam : '',
          monthDisp_(per.ky), per.chucDanh, per.phongBan, per.maPL, per.dong, per.luongDong, per.tongNLD, per.tongDN, per.tongCong, per.canhBao]);
      });
    });
    return {
      info: d.info, title: 'TỔNG HỢP THEO NHÂN SỰ – TỪ ' + monthDisp_(d.tuKy) + ' ĐẾN ' + monthDisp_(d.denKy),
      fileName: 'BHXH_NhanSu_' + d.tuKy + '_' + d.denKy,
      sections: [{ title: '', header: header, rows: rows, numCols: [7, 13, 14, 15, 16] }]
    };
  }
  throw new Error('Loại báo cáo không hợp lệ.');
}
function makeFile_(doc, format) {
  const width = Math.max.apply(null, doc.sections.map(function (s) { return s.header.length; }).concat([4]));
  const grid = [];
  const styles = []; // {row, type, len, numCols}
  const push = function (arr) { const a = arr.slice(); while (a.length < width) a.push(''); grid.push(a); };
  push([doc.info.tenCty || '']);
  push([(doc.info.mst ? 'MST: ' + doc.info.mst : '') + (doc.info.diaChi ? '   Địa chỉ: ' + doc.info.diaChi : '')]);
  push([doc.title]); styles.push({ row: grid.length, type: 'title' });
  push([doc.subtitle || ('Ngày xuất: ' + now_())]);
  push([]);
  doc.sections.forEach(function (s) {
    if (s.title) { push([s.title]); styles.push({ row: grid.length, type: 'sec' }); }
    push(s.header); styles.push({ row: grid.length, type: 'head', len: s.header.length });
    const start = grid.length + 1;
    s.rows.forEach(push);
    if (s.total) {
      const totals = Array.isArray(s.total[0]) ? s.total : [s.total];
      totals.forEach(function (t) { push(t); styles.push({ row: grid.length, type: 'total', len: s.header.length }); });
    }
    const end = grid.length;
    if (end >= start) styles.push({ type: 'num', start: start, end: end, cols: s.numCols || [], len: s.header.length });
    push([]);
  });

  const tmp = SpreadsheetApp.create(doc.fileName);
  try {
    const sh = tmp.getSheets()[0];
    sh.setName('Bao cao');
    if (sh.getMaxColumns() < width) sh.insertColumnsAfter(sh.getMaxColumns(), width - sh.getMaxColumns());
    if (sh.getMaxRows() < grid.length) sh.insertRowsAfter(sh.getMaxRows(), grid.length - sh.getMaxRows());
    const rg = sh.getRange(1, 1, grid.length, width);
    rg.setNumberFormat('@');
    styles.forEach(function (st) {
      if (st.type === 'num') st.cols.forEach(function (c) { sh.getRange(st.start, c + 1, st.end - st.start + 1, 1).setNumberFormat('#,##0'); });
    });
    rg.setValues(grid).setFontFamily('Arial').setFontSize(9).setVerticalAlignment('middle');
    sh.getRange(1, 1).setFontWeight('bold');
    styles.forEach(function (st) {
      if (st.type === 'title') sh.getRange(st.row, 1).setFontWeight('bold').setFontSize(14);
      if (st.type === 'sec') sh.getRange(st.row, 1).setFontWeight('bold').setFontSize(11);
      if (st.type === 'head') sh.getRange(st.row, 1, 1, st.len).setFontWeight('bold').setBackground('#dbe5f1').setWrap(true).setHorizontalAlignment('center');
      if (st.type === 'total') sh.getRange(st.row, 1, 1, st.len).setFontWeight('bold').setBackground('#f2f2f2');
      if (st.type === 'num') sh.getRange(st.start - 1, 1, st.end - st.start + 2, st.len).setBorder(true, true, true, true, true, true, '#999999', SpreadsheetApp.BorderStyle.SOLID);
    });
    sh.autoResizeColumns(1, width);
    sh.setColumnWidth(1, 60);
    SpreadsheetApp.flush();
    return exportSpreadsheet_(tmp.getId(), doc.fileName, format);
  } finally {
    DriveApp.getFileById(tmp.getId()).setTrashed(true);
  }
}

/** Xuất một Google Sheet tạm (id) ra xlsx/pdf/csv và trả về {name, mime, data(base64)} */
function exportSpreadsheet_(id, baseName, format) {
  const q = format === 'pdf'
    ? 'format=pdf&size=A4&portrait=false&fitw=true&gridlines=false&printtitle=false&sheetnames=false&pagenum=CENTER&top_margin=0.4&bottom_margin=0.4&left_margin=0.3&right_margin=0.3'
    : format === 'csv' ? 'format=csv&gid=0'
    : 'format=xlsx';
  const resp = UrlFetchApp.fetch('https://docs.google.com/spreadsheets/d/' + id + '/export?' + q, {
    headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() }, muteHttpExceptions: true
  });
  if (resp.getResponseCode() !== 200) throw new Error('Không xuất được file (mã lỗi ' + resp.getResponseCode() + ').');
  const ext = format === 'pdf' ? '.pdf' : format === 'csv' ? '.csv' : '.xlsx';
  const mime = format === 'pdf' ? 'application/pdf' : format === 'csv' ? 'text/csv'
    : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
  return { name: baseName + ext, mime: mime, data: Utilities.base64Encode(resp.getBlob().getBytes()) };
}

// ---------------------------------------------------------------------
// IMPORT / EXPORT / FILE MẪU – TAB NHÂN VIÊN
// ---------------------------------------------------------------------
function numberFormatsForCols_(cols) {
  const out = [];
  cols.forEach(function (c, i) {
    if (c[2] === 'num' || c[2] === 'pct') out.push({ col: i + 1, fmt: '#,##0' });
    else if (c[2] === 'date') out.push({ col: i + 1, fmt: 'dd/MM/yyyy' });
  });
  return out;
}

/** Tạo Sheet tạm từ lưới dữ liệu trong bộ nhớ, xuất ra file rồi xóa Sheet tạm.
 *  extraSheets (tuỳ chọn): [{name, grid}] – các sheet tham khảo thêm (vd. Danh mục cho dropdown),
 *  chỉ xuất hiện trong file Excel (.xlsx); khi xuất CSV chỉ sheet "Data" đầu tiên được lấy. */
function makeGridFile_(fileName, grid, headerRow, numberFormats, format, extraSheets) {
  const width = Math.max.apply(null, grid.map(function (r) { return r.length; }).concat([1]));
  const norm = grid.map(function (r) { const a = r.slice(); while (a.length < width) a.push(''); return a; });
  const tmp = SpreadsheetApp.create(fileName);
  try {
    const sh = tmp.getSheets()[0];
    sh.setName('Data');
    if (sh.getMaxColumns() < width) sh.insertColumnsAfter(sh.getMaxColumns(), width - sh.getMaxColumns());
    if (sh.getMaxRows() < norm.length) sh.insertRowsAfter(sh.getMaxRows(), norm.length - sh.getMaxRows());
    const rg = sh.getRange(1, 1, norm.length, width);
    rg.setNumberFormat('@'); // mặc định dạng văn bản để tránh Sheet tự suy diễn ngày/số sai
    (numberFormats || []).forEach(function (nf) {
      sh.getRange(headerRow + 1, nf.col, Math.max(norm.length - headerRow, 1), 1).setNumberFormat(nf.fmt);
    });
    rg.setValues(norm).setFontFamily('Arial').setFontSize(10);
    if (headerRow) {
      sh.getRange(headerRow, 1, 1, width).setFontWeight('bold').setBackground('#dbe5f1').setWrap(true);
      sh.setFrozenRows(headerRow);
    }
    sh.autoResizeColumns(1, width);
    (extraSheets || []).forEach(function (es) {
      const ew = Math.max.apply(null, es.grid.map(function (r) { return r.length; }).concat([1]));
      const en = es.grid.map(function (r) { const a = r.slice(); while (a.length < ew) a.push(''); return a; });
      const esh = tmp.insertSheet(es.name);
      if (esh.getMaxColumns() < ew) esh.insertColumnsAfter(esh.getMaxColumns(), ew - esh.getMaxColumns());
      if (esh.getMaxRows() < en.length) esh.insertRowsAfter(esh.getMaxRows(), en.length - esh.getMaxRows());
      esh.getRange(1, 1, en.length, ew).setNumberFormat('@').setValues(en).setFontFamily('Arial').setFontSize(10);
      esh.getRange(1, 1, 1, ew).setFontWeight('bold').setBackground('#dbe5f1').setWrap(true);
      esh.setFrozenRows(1);
      esh.autoResizeColumns(1, ew);
    });
    SpreadsheetApp.flush();
    return exportSpreadsheet_(tmp.getId(), fileName, format);
  } finally {
    DriveApp.getFileById(tmp.getId()).setTrashed(true);
  }
}

/** File mẫu để nhập danh sách nhân viên */
function apiTemplateNV(format) {
  getUser_();
  const header = T.NV.cols.map(function (c) { return c[1]; });
  const pb0 = (load_(T.PB).rows[0] || {}).ten || 'Phòng Hành chính - Nhân sự';
  const mau = [
    { maNV: 'NV001', hoTen: 'Nguyễn Văn A', maBHXH: '0123456789', ngaySinh: '1990-05-20', gioiTinh: NAM, phongBan: pb0,
      chucDanh: 'Nhân viên', ngayVao: '2024-01-01', ngayBHXH: '2024-01-01', ngayNghi: '', thangDung: '', luongChinh: 8000000,
      pcKN: 0, pcCV: 0, pcDH: 0, pcKhac: 0, luongDong: 8000000, maPL: 'CT', congDoan: CO, emailQL: '', ghiChu: 'Dòng ví dụ – xóa trước khi nhập' },
    { maNV: 'NV002', hoTen: 'Trần Thị B', maBHXH: '0987654321', ngaySinh: '1995-11-02', gioiTinh: NU, phongBan: pb0,
      chucDanh: 'Chuyên viên', ngayVao: '2023-03-15', ngayBHXH: '2023-03-15', ngayNghi: '', thangDung: '', luongChinh: 12000000,
      pcKN: 0, pcCV: 500000, pcDH: 0, pcKhac: 0, luongDong: 12500000, maPL: 'CT', congDoan: KHONG, emailQL: '', ghiChu: 'Dòng ví dụ – xóa trước khi nhập' }
  ];
  const grid = [header].concat(mau.map(function (o) { return buildRow_(T.NV, header, o, null); }));
  return makeGridFile_('Mau_DanhSachNhanVien', grid, 1, numberFormatsForCols_(T.NV.cols), format === 'csv' ? 'csv' : 'xlsx',
    [{ name: 'Danh mục', grid: danhMucNVGrid_() }]);
}
/** Lưới "Danh mục" liệt kê đúng các giá trị hợp lệ của từng trường dropdown (Phòng ban, Mã phân loại, Tham gia
 *  công đoàn) theo cấu hình hiện tại, để đính kèm vào file mẫu – nhập giá trị khác các danh mục này sẽ bị từ chối. */
function danhMucNVGrid_() {
  const pbRows = load_(T.PB).rows.map(function (r) { return r.ten; }).filter(String);
  const plRows = load_(T.MAPL).rows.filter(function (r) { return r.ma; });
  const cdRows = [CO, KHONG];
  const gtRows = LISTS.gioiTinh;
  const n = Math.max(pbRows.length, plRows.length, cdRows.length, gtRows.length, 1);
  const grid = [['Đơn vị_Phòng ban (danh mục)', 'Mã phân loại (danh mục)', 'Mô tả mã phân loại', 'Tham gia công đoàn (danh mục)', 'Giới tính (danh mục)']];
  for (let i = 0; i < n; i++) {
    const pl = plRows[i];
    grid.push([
      pbRows[i] || '',
      pl ? pl.ma : '',
      pl ? (pl.moTa || '') + (pl.trangThai === TT_NGUNG ? ' (Ngừng áp dụng)' : '') : '',
      cdRows[i] || '',
      gtRows[i] || ''
    ]);
  }
  return grid;
}

/** Xuất danh sách nhân viên hiện tại (hồ sơ gốc hoặc một kỳ) */
function apiExportNV(ky, format) {
  getUser_();
  ky = normMonth_(ky);
  const d = apiNhanVien(ky);
  const header = T.NV.cols.map(function (c) { return c[1]; });
  const rows = d.rows.map(function (r) { return buildRow_(T.NV, header, r, null); });
  const grid = [header].concat(rows);
  const fname = 'DanhSachNhanVien_' + (ky || 'HoSoGoc');
  return makeGridFile_(fname, grid, 1, numberFormatsForCols_(T.NV.cols), format === 'csv' ? 'csv' : 'xlsx');
}

function normHeader_(s) { return String(s === null || s === undefined ? '' : s).trim().toLowerCase().replace(/\s+/g, ' '); }

/** Tìm dòng tiêu đề thật trong file (bỏ qua các dòng tiêu đề công ty/ghi chú phía trên, nếu có) */
function findHeaderRow_(grid, requiredTitles) {
  const req = (requiredTitles || ['Mã NV', 'Họ và tên']).map(normHeader_);
  for (let r = 0; r < Math.min(grid.length, 15); r++) {
    const norm = (grid[r] || []).map(normHeader_);
    if (req.every(function (w) { return norm.indexOf(w) >= 0; })) return r;
  }
  return -1;
}

/**
 * Chuyển lưới 2 chiều (có dòng tiêu đề) thành danh sách object theo cols của bảng t.
 * Chỉ những cột có tên trùng với tiêu đề trong file mới được gán giá trị (khóa để undefined nếu không có trong file) –
 * nhờ đó chế độ "cập nhật 1 phần" giữ nguyên các cột không có trong file khi ghi (buildRow_ chỉ đổi cột được gán).
 */
function gridToObjects_(cols, grid, requiredTitles) {
  const hr = findHeaderRow_(grid, requiredTitles);
  if (hr < 0) {
    return { objs: [], error: 'Không tìm thấy dòng tiêu đề (phải có đủ cột ' + (requiredTitles || ['Mã NV', 'Họ và tên']).map(function (x) { return '"' + x + '"'; }).join(' và ') + '). '
      + 'Hãy tải file mẫu (nút "Tải file mẫu") và giữ nguyên tên cột.' };
  }
  const norm = grid[hr].map(normHeader_);
  const idx = {}, type = {}, matched = [];
  cols.forEach(function (c) {
    const i = norm.indexOf(normHeader_(c[1]));
    if (i >= 0) { idx[c[0]] = i; type[c[0]] = c[2]; matched.push(c[0]); }
  });
  const objs = [];
  for (let r = hr + 1; r < grid.length; r++) {
    const row = grid[r];
    if (!row || row.every(function (x) { return x === '' || x === null || x === undefined; })) continue;
    const o = { _line: r + 1 };
    matched.forEach(function (k) { o[k] = fromCell_(type[k], row[idx[k]]); });
    objs.push(o);
  }
  return { objs: objs, matched: matched };
}

/** Đọc file người dùng tải lên (base64) thành lưới 2 chiều */
function parseUploadedGrid_(fileB64, fileName) {
  const ext = String(fileName || '').toLowerCase().split('.').pop();
  let bytes;
  try { bytes = Utilities.base64Decode(fileB64); } catch (e) { throw new Error('File tải lên bị lỗi, hãy chọn lại file.'); }
  if (ext === 'csv' || ext === 'txt') {
    return parseTextGrid_(Utilities.newBlob(bytes).getDataAsString('UTF-8'));
  }
  if (ext === 'xlsx' || ext === 'xls') {
    const mime = ext === 'xls' ? 'application/vnd.ms-excel' : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    return convertXlsxToRows_(Utilities.newBlob(bytes, mime, fileName));
  }
  throw new Error('Chỉ hỗ trợ file .csv, .xlsx hoặc .xls.');
}

/** Chuyển văn bản dán trực tiếp (CSV/TSV) thành lưới giá trị, tự nhận diện dấu phân cách (tab/;/,) */
function parseTextGrid_(text) {
  text = String(text === null || text === undefined ? '' : text);
  if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1); // bỏ BOM nếu có
  const firstLine = text.split('\n')[0] || '';
  const counts = { '\t': firstLine.split('\t').length, ';': firstLine.split(';').length, ',': firstLine.split(',').length };
  const delim = Object.keys(counts).reduce(function (a, b) { return counts[b] > counts[a] ? b : a; }, ',');
  return Utilities.parseCsv(text, delim);
}

/** Chuyển file Excel thành lưới giá trị bằng cách tạo bản Google Sheet tạm thời (Drive API) */
function convertXlsxToRows_(blob) {
  let file;
  try {
    file = Drive.Files.create({ name: 'BHXH_import_tmp', mimeType: MimeType.GOOGLE_SHEETS }, blob);
  } catch (e) {
    throw new Error('Không đọc được file Excel. Trong Apps Script, vào mục "Dịch vụ" (Services, dấu ⊕ ở thanh bên) '
      + 'và thêm "Drive API" (phiên bản v3), lưu lại rồi thử lại. Hoặc lưu file dưới dạng CSV (.csv) rồi tải lên. '
      + 'Lỗi gốc: ' + e.message);
  }
  try {
    const ss = SpreadsheetApp.openById(file.id);
    return ss.getSheets()[0].getDataRange().getValues();
  } finally {
    try { Drive.Files.remove(file.id); } catch (e2) { /* bỏ qua lỗi dọn dẹp */ }
  }
}

/**
 * Nhập danh sách nhân viên từ file CSV/Excel.
 * mode: 'themmoi' = thêm mới nhân viên chưa có, cập nhật nếu Mã NV đã tồn tại (bỏ qua dòng lỗi).
 *       'thaythe' = thay thế hoàn toàn danh sách hiện tại (trong phạm vi được quản lý) bằng file – nếu có bất kỳ
 *                   dòng lỗi thì KHÔNG thay đổi gì cả, để tránh mất dữ liệu.
 *       'motphan' = chỉ cập nhật các cột có trong file cho NV đã tồn tại (giữ nguyên các cột khác, không tạo mới).
 * onlyEmpty: chỉ dùng cho mode 'motphan' – true = chỉ điền vào ô còn trống, không ghi đè dữ liệu đã có.
 */
function apiImportNV(ky, mode, fileB64, fileName, onlyEmpty) {
  return importNVGrid_(ky, mode, parseUploadedGrid_(fileB64, fileName), fileName, onlyEmpty);
}

/** Nhập danh sách nhân viên từ văn bản dán trực tiếp (CSV/TSV) – không cần chọn file. */
function apiImportNVText(ky, mode, text, onlyEmpty) {
  if (!String(text || '').trim()) throw new Error('Chưa dán dữ liệu.');
  return importNVGrid_(ky, mode, parseTextGrid_(text), 'dán trực tiếp', onlyEmpty);
}

function importNVGrid_(ky, mode, grid, source, onlyEmpty) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN, ROLE.NHAP]);
  ky = normMonth_(ky);
  return withLock_(function () {
    if (ky) requireOpen_(ky);
    const parsed = gridToObjects_(T.NV.cols, grid, mode === 'motphan' ? ['Mã NV'] : ['Mã NV', 'Họ và tên']);
    if (parsed.error) throw new Error(parsed.error);
    if (!parsed.objs.length) throw new Error('Không có dòng dữ liệu nào.');
    if (mode === 'motphan') return importPartialNV_(user, ky, parsed, source, onlyEmpty);

    const kys = listKy_();
    const latest = kys.length ? kys[0].ky : '';
    const applyToMaster = !ky || ky >= latest;
    const mm = maplMap_();
    const pbm = pbMap_();

    const dNV = load_(T.NV);
    const dlRowsForKy = ky ? load_(T.DLKY).rows.filter(function (r) { return r.ky === ky; }) : [];
    const nvByCode = {}; dNV.rows.forEach(function (r) { nvByCode[r.maNV] = r; });
    const dlByCode = {}; dlRowsForKy.forEach(function (r) { dlByCode[r.maNV] = r; });

    const errors = [];
    const seen = {};
    const cleaned = [];
    parsed.objs.forEach(function (raw) {
      const code = String(raw.maNV || '').trim();
      try {
        const existing = ky ? dlByCode[code] : nvByCode[code];
        if (existing && !canSee_(user, existing)) throw new Error('Không có quyền sửa hồ sơ này (đã có người khác quản lý).');
        const obj = cleanNV_(raw, user, mm, pbm);
        if (seen[obj.maNV]) throw new Error('Trùng Mã NV với dòng ' + seen[obj.maNV] + ' trong file.');
        seen[obj.maNV] = raw._line;
        cleaned.push({ line: raw._line, code: obj.maNV, obj: obj, existing: existing });
      } catch (e) {
        errors.push({ line: raw._line, maNV: code, message: e.message });
      }
    });

    if (mode === 'thaythe') {
      if (errors.length) return { mode: mode, added: 0, updated: 0, deleted: 0, total: parsed.objs.length, errors: errors };
      const delNV = user.role === ROLE.ADMIN ? dNV.rows : dNV.rows.filter(function (r) { return canSee_(user, r); });
      const delDL = user.role === ROLE.ADMIN ? dlRowsForKy : dlRowsForKy.filter(function (r) { return canSee_(user, r); });
      if (applyToMaster && delNV.length) deleteRows_(T.NV, delNV.map(function (r) { return r._row; }));
      if (ky && delDL.length) deleteRows_(T.DLKY, delDL.map(function (r) { return r._row; }));
      const toInsert = cleaned.map(function (c) { return c.obj; });
      if (applyToMaster) append_(T.NV, toInsert);
      if (ky) append_(T.DLKY, toInsert.map(function (o) { return Object.assign({ ky: ky }, o); }));
      log_(user, 'Import NV (thay thế)', (ky ? 'Kỳ ' + monthDisp_(ky) : 'Hồ sơ gốc') + ' – ' + toInsert.length + ' NV từ ' + source);
      return { mode: mode, added: toInsert.length, updated: 0, deleted: delNV.length, total: parsed.objs.length, errors: [] };
    }

    // mode 'themmoi': thêm mới hoặc cập nhật, bỏ qua dòng lỗi
    let added = 0, updated = 0;
    const newMaster = [], newDL = [];
    cleaned.forEach(function (c) {
      if (applyToMaster) {
        const exM = nvByCode[c.code];
        if (exM) { update_(T.NV, exM._row, c.obj); updated++; } else { newMaster.push(c.obj); added++; }
      }
      if (ky) {
        const exD = dlByCode[c.code];
        if (exD) { update_(T.DLKY, exD._row, c.obj); if (!applyToMaster) updated++; }
        else { newDL.push(Object.assign({ ky: ky }, c.obj)); if (!applyToMaster) added++; }
      }
    });
    if (newMaster.length) append_(T.NV, newMaster);
    if (newDL.length) append_(T.DLKY, newDL);
    log_(user, 'Import NV (thêm/cập nhật)', (ky ? 'Kỳ ' + monthDisp_(ky) : 'Hồ sơ gốc') + ' – ' + added + ' thêm, ' + updated
      + ' cập nhật từ ' + source + (errors.length ? ', ' + errors.length + ' dòng lỗi bị bỏ qua' : ''));
    return { mode: mode, added: added, updated: updated, deleted: 0, total: parsed.objs.length, errors: errors };
  });
}

/**
 * Chế độ "cập nhật 1 phần": chỉ ghi vào các cột có trong file, giữ nguyên các cột khác; không tạo NV mới.
 * onlyEmpty = true: chỉ điền vào ô hiện đang trống (chuỗi rỗng, hoặc 0 với các cột số), không ghi đè dữ liệu đã có.
 */
function importPartialNV_(user, ky, parsed, source, onlyEmpty) {
  const matched = parsed.matched.filter(function (k) { return k !== 'maNV'; });
  if (!matched.length) throw new Error('File chỉ có cột Mã NV, không có cột nào khác để cập nhật.');
  const kys = listKy_();
  const latest = kys.length ? kys[0].ky : '';
  const applyToMaster = !ky || ky >= latest;
  const mm = maplMap_();
  const pbm = pbMap_();
  const dNV = load_(T.NV);
  const dlRowsForKy = ky ? load_(T.DLKY).rows.filter(function (r) { return r.ky === ky; }) : [];
  const nvByCode = {}; dNV.rows.forEach(function (r) { nvByCode[r.maNV] = r; });
  const dlByCode = {}; dlRowsForKy.forEach(function (r) { dlByCode[r.maNV] = r; });

  let updated = 0, skipped = 0;
  const errors = [];
  parsed.objs.forEach(function (raw) {
    const code = String(raw.maNV || '').trim();
    try {
      if (!code) throw new Error('Thiếu Mã NV.');
      const target = ky ? dlByCode[code] : nvByCode[code];
      if (!target) throw new Error('Không tìm thấy Mã NV này (chế độ cập nhật 1 phần không tạo NV mới).');
      if (!canSee_(user, target)) throw new Error('Không có quyền sửa hồ sơ này (đã có người khác quản lý).');
      const patch = mergeNVPartial_(target, raw, matched, user, mm, onlyEmpty, pbm);
      if (!patch) { skipped++; return; }
      if (ky) { const exD = dlByCode[code]; if (exD) update_(T.DLKY, exD._row, patch); }
      if (applyToMaster) { const exM = nvByCode[code]; if (exM) update_(T.NV, exM._row, patch); }
      updated++;
    } catch (e) {
      errors.push({ line: raw._line, maNV: code, message: e.message });
    }
  });
  log_(user, 'Import NV (cập nhật 1 phần)', (ky ? 'Kỳ ' + monthDisp_(ky) : 'Hồ sơ gốc') + ' – ' + updated + ' cập nhật, '
    + skipped + ' không đổi, cột: ' + matched.join(', ') + ' từ ' + source);
  return { mode: 'motphan', added: 0, updated: updated, deleted: 0, skipped: skipped, total: parsed.objs.length, errors: errors, cols: matched };
}

/** Tính patch (chỉ các trường cần đổi) khi cập nhật 1 phần cho một NV; trả về null nếu không có gì thay đổi. */
function mergeNVPartial_(existing, raw, matchedKeys, user, mm, onlyEmpty, pbMapObj) {
  const patch = {};
  matchedKeys.forEach(function (k) {
    const v = raw[k];
    if (onlyEmpty) {
      const cur = existing[k];
      const empty = (typeof cur === 'number') ? cur === 0 : !cur;
      if (!empty) return; // đã có dữ liệu, giữ nguyên
    }
    patch[k] = v;
  });
  if (!Object.keys(patch).length) return null;
  if (patch.phongBan !== undefined) patch.phongBan = checkPhongBan_(patch.phongBan, pbMapObj);
  if (patch.congDoan !== undefined) patch.congDoan = checkCongDoan_(patch.congDoan);
  if (patch.gioiTinh !== undefined) patch.gioiTinh = checkGioiTinh_(patch.gioiTinh);
  if (patch.emailQL !== undefined) {
    patch.emailQL = String(patch.emailQL || '').toLowerCase().trim();
    if (user.role === ROLE.NHAP) patch.emailQL = user.email;
  }
  if (patch.maPL !== undefined && patch.maPL && !mm[patch.maPL]) throw new Error('Mã phân loại "' + patch.maPL + '" không tồn tại.');
  if (['luongChinh', 'pcKN', 'pcCV', 'pcDH', 'pcKhac'].some(function (k) { return patch[k] !== undefined; })) {
    const merged = Object.assign({}, existing, patch);
    patch.luongDong = luongDong_(merged);
  }
  const thangDung = patch.thangDung !== undefined ? patch.thangDung : existing.thangDung;
  const ngayBHXH = patch.ngayBHXH !== undefined ? patch.ngayBHXH : existing.ngayBHXH;
  if ((patch.thangDung !== undefined || patch.ngayBHXH !== undefined) && thangDung && ngayBHXH && normMonth_(thangDung) < ngayBHXH.slice(0, 7)) {
    throw new Error('Tháng dừng đóng không được trước tháng bắt đầu BHXH.');
  }
  return patch;
}

// ---------------------------------------------------------------------
// API: THIẾT LẬP (Admin)
// ---------------------------------------------------------------------
function apiSaveInfo(o) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  const sh = SpreadsheetApp.getActive().getSheetByName(INFO_SHEET);
  if (!sh) throw new Error('Không tìm thấy tab "' + INFO_SHEET + '".');
  const lr = Math.max(sh.getLastRow(), 1);
  const labels = lr > 1 ? sh.getRange(2, 1, lr - 1, 1).getValues().map(function (r) { return String(r[0]).trim(); }) : [];
  INFO_FIELDS.forEach(function (f) {
    if (o[f[0]] === undefined) return;
    let i = labels.indexOf(f[1]);
    let row;
    if (i < 0) { row = sh.getLastRow() + 1; sh.getRange(row, 1).setValue(f[1]); labels.push(f[1]); }
    else row = i + 2;
    const isNum = INFO_NUM_FIELDS.indexOf(f[0]) >= 0;
    sh.getRange(row, 2).setNumberFormat(isNum ? INFO_NUM_FMT[f[0]] : '@').setValue(isNum ? moneyNum_(o[f[0]]) : String(o[f[0]]));
  });
  log_(user, 'Sửa thông tin chung', '');
  return getInfo_();
}

function apiSavePhongBan(list) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  const names = [];
  (list || []).forEach(function (x) { x = String(x).trim(); if (x && names.indexOf(x) < 0) names.push(x); });
  return withLock_(function () {
    const d = load_(T.PB);
    const note = {};
    d.rows.forEach(function (r) { note[r.ten] = r.ghiChu; });
    const sh = d.sh;
    if (sh.getLastRow() > 1) sh.getRange(2, 1, sh.getLastRow() - 1, sh.getLastColumn()).clearContent();
    append_(T.PB, names.map(function (n) { return { ten: n, ghiChu: note[n] || '' }; }));
    log_(user, 'Cập nhật phòng ban', names.length + ' đơn vị');
    return names;
  });
}

function apiSaveKhoan(o) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  const r = {
    ten: String(o.ten || '').trim(), ma: String(o.ma || '').trim().toUpperCase(), doiTuong: o.doiTuong,
    tiLe: num_(o.tiLe), loaiTran: o.loaiTran || TRAN_KHONG, mucToiDa: moneyNum_(o.mucToiDa),
    ngayHL: normDate_(o.ngayHL), trangThai: o.trangThai || TT_AD, chiDoanVien: o.chiDoanVien === CO ? CO : KHONG,
    thuocCD: o.thuocCD === CO ? CO : KHONG, ghiChu: o.ghiChu || ''
  };
  if (!r.ten || !r.ma) throw new Error('Chưa nhập Tên khoản hoặc Mã nhận diện.');
  if (!/^[A-Z0-9_]+$/.test(r.ma)) throw new Error('Mã nhận diện chỉ gồm chữ không dấu, số và dấu gạch dưới (VD: BHXH_NLD).');
  if (LISTS.doiTuong.indexOf(r.doiTuong) < 0) throw new Error('Đối tượng áp dụng không hợp lệ.');
  if (!r.ngayHL) throw new Error('Chưa nhập Ngày hiệu lực.');
  if (r.loaiTran !== TRAN_KHONG && r.mucToiDa <= 0) throw new Error('Chưa nhập Mức tối đa cho loại trần đã chọn.');
  return withLock_(function () {
    const d = load_(T.KHOAN);
    const other = d.rows.filter(function (x) { return x.ma === r.ma && (!o._row || x._row !== o._row); });
    if (other.some(function (x) { return x.doiTuong !== r.doiTuong; })) throw new Error('Mã ' + r.ma + ' đã được dùng cho đối tượng khác.');
    if (other.some(function (x) { return x.ngayHL === r.ngayHL; })) throw new Error('Mã ' + r.ma + ' đã có phiên bản cùng ngày hiệu lực ' + dateDisp_(r.ngayHL) + '.');
    if (o._row) {
      const ex = d.rows.find(function (x) { return x._row === Number(o._row); });
      if (!ex) throw new Error('Không tìm thấy dòng cần sửa.');
      r.id = ex.id;
      update_(T.KHOAN, ex._row, r);
    } else {
      r.id = 'K' + Date.now();
      append_(T.KHOAN, [r]);
    }
    log_(user, 'Lưu khoản trích', r.ma + ' ' + r.tiLe + '% từ ' + dateDisp_(r.ngayHL));
    return load_(T.KHOAN).rows;
  });
}

function apiDeleteKhoan(row) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  return withLock_(function () {
    const ex = load_(T.KHOAN).rows.find(function (x) { return x._row === Number(row); });
    if (!ex) throw new Error('Không tìm thấy dòng.');
    deleteRows_(T.KHOAN, [ex._row]);
    log_(user, 'Xóa khoản trích', ex.ma + ' hiệu lực ' + dateDisp_(ex.ngayHL));
    return load_(T.KHOAN).rows;
  });
}

function apiListTyLeCD() { getUser_(); return load_(T.TLCD).rows; }

function apiSaveTyLeCD(o) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  const r = { tyLeGiuLaiNLD: num_(o.tyLeGiuLaiNLD), tyLeGiuLaiDN: num_(o.tyLeGiuLaiDN), ngayHL: normDate_(o.ngayHL), ghiChu: o.ghiChu || '' };
  if (r.tyLeGiuLaiNLD < 0 || r.tyLeGiuLaiNLD > 100) throw new Error('Tỉ lệ giữ lại Đoàn phí (NLĐ) phải trong khoảng 0 – 100.');
  if (r.tyLeGiuLaiDN < 0 || r.tyLeGiuLaiDN > 100) throw new Error('Tỉ lệ giữ lại Kinh phí công đoàn (DN) phải trong khoảng 0 – 100.');
  if (!r.ngayHL) throw new Error('Chưa nhập Ngày hiệu lực.');
  return withLock_(function () {
    const d = load_(T.TLCD);
    if (d.rows.some(function (x) { return x.ngayHL === r.ngayHL && (!o._row || x._row !== Number(o._row)); })) {
      throw new Error('Đã có phiên bản khác với cùng ngày hiệu lực ' + dateDisp_(r.ngayHL) + '.');
    }
    if (o._row) {
      const ex = d.rows.find(function (x) { return x._row === Number(o._row); });
      if (!ex) throw new Error('Không tìm thấy dòng cần sửa.');
      r.id = ex.id;
      update_(T.TLCD, ex._row, r);
    } else {
      r.id = 'TL' + Date.now();
      append_(T.TLCD, [r]);
    }
    log_(user, 'Lưu tỉ lệ Công đoàn', 'NLĐ ' + r.tyLeGiuLaiNLD + '%, DN ' + r.tyLeGiuLaiDN + '% giữ lại từ ' + dateDisp_(r.ngayHL));
    return load_(T.TLCD).rows;
  });
}

function apiDeleteTyLeCD(row) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  return withLock_(function () {
    const ex = load_(T.TLCD).rows.find(function (x) { return x._row === Number(row); });
    if (!ex) throw new Error('Không tìm thấy dòng.');
    deleteRows_(T.TLCD, [ex._row]);
    log_(user, 'Xóa tỉ lệ Công đoàn', 'NLĐ ' + ex.tyLeGiuLaiNLD + '%, DN ' + ex.tyLeGiuLaiDN + '% hiệu lực ' + dateDisp_(ex.ngayHL));
    return load_(T.TLCD).rows;
  });
}

function apiSaveMaPL(o, isNew) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  const ma = String(o.ma || '').trim();
  if (!ma) throw new Error('Chưa nhập Mã phân loại.');
  const ten = khoanTen_(load_(T.KHOAN).rows);
  const nld = [], dn = [];
  (o.ds || []).forEach(function (x) {
    const k = ten[x.ma];
    if (!k) return;
    const s = x.ma + (x.tiLe !== null && x.tiLe !== '' && x.tiLe !== undefined ? '=' + num_(x.tiLe) : '');
    (k.doiTuong === DT_DN ? dn : nld).push(s);
  });
  const r = { ma: ma, moTa: o.moTa || '', trangThai: o.trangThai || TT_AD, khoanNLD: nld.join('; '), khoanDN: dn.join('; '), ghiChu: o.ghiChu || '' };
  return withLock_(function () {
    const d = load_(T.MAPL);
    const ex = d.rows.find(function (x) { return x.ma === ma; });
    if (isNew) { if (ex) throw new Error('Mã phân loại "' + ma + '" đã tồn tại.'); append_(T.MAPL, [r]); }
    else { if (!ex) throw new Error('Không tìm thấy mã phân loại.'); update_(T.MAPL, ex._row, r); }
    log_(user, 'Lưu mã phân loại', ma + ' | NLĐ: ' + r.khoanNLD + ' | DN: ' + r.khoanDN);
    return load_(T.MAPL).rows;
  });
}

function apiDeleteMaPL(ma) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  return withLock_(function () {
    const used = load_(T.NV).rows.concat(load_(T.DLKY).rows).some(function (r) { return r.maPL === ma; });
    if (used) throw new Error('Mã "' + ma + '" đang được sử dụng. Hãy chuyển Trạng thái sang "Ngừng áp dụng" thay vì xóa.');
    const ex = load_(T.MAPL).rows.find(function (x) { return x.ma === ma; });
    if (!ex) throw new Error('Không tìm thấy mã.');
    deleteRows_(T.MAPL, [ex._row]);
    log_(user, 'Xóa mã phân loại', ma);
    return load_(T.MAPL).rows;
  });
}

function apiPhanQuyen() {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  return load_(T.PQ).rows;
}

function apiSavePQ(o) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  const r = { email: String(o.email || '').toLowerCase().trim(), hoTen: o.hoTen || '', vaiTro: o.vaiTro, trangThai: o.trangThai || PQ_HD, ghiChu: o.ghiChu || '' };
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(r.email)) throw new Error('Email không hợp lệ.');
  if (LISTS.role.indexOf(r.vaiTro) < 0) throw new Error('Vai trò không hợp lệ.');
  return withLock_(function () {
    const d = load_(T.PQ);
    const ex = d.rows.find(function (x) { return x.email.toLowerCase() === r.email; });
    if (ex && ex.email.toLowerCase() === user.email && (r.vaiTro !== ROLE.ADMIN || r.trangThai === PQ_KHOA)) {
      throw new Error('Bạn không thể tự hạ quyền hoặc khóa chính mình.');
    }
    if (ex) update_(T.PQ, ex._row, r); else append_(T.PQ, [r]);
    log_(user, 'Phân quyền', r.email + ' → ' + r.vaiTro + ' (' + r.trangThai + ')');
    return load_(T.PQ).rows;
  });
}

function apiDeletePQ(email) {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  email = String(email).toLowerCase();
  if (email === user.email) throw new Error('Bạn không thể xóa chính mình.');
  return withLock_(function () {
    const ex = load_(T.PQ).rows.find(function (x) { return x.email.toLowerCase() === email; });
    if (!ex) throw new Error('Không tìm thấy.');
    deleteRows_(T.PQ, [ex._row]);
    log_(user, 'Xóa phân quyền', email);
    return load_(T.PQ).rows;
  });
}

function apiNhatKy() {
  const user = getUser_();
  requireRole_(user, [ROLE.ADMIN]);
  return load_(T.LOG).rows.slice(-500).reverse();
}
